//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateCoriolisMatrix.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "calculateCoriolisMatrix.h"
#include "calculateJacobiansTimeDerivative.h"
#include "forward_dynamics_internal_types.h"
#include "forward_dynamics_types.h"
#include "mtimes.h"
#include "coder_array.h"
#include <cstring>

// Function Declarations
static void binary_expand_op(coder::array<double, 2U> &in1,
                             const coder::array<double, 2U> &in2,
                             const coder::array<double, 2U> &in3);

// Function Definitions
//
// Arguments    : coder::array<double, 2U> &in1
//                const coder::array<double, 2U> &in2
//                const coder::array<double, 2U> &in3
// Return Type  : void
//
static void binary_expand_op(coder::array<double, 2U> &in1,
                             const coder::array<double, 2U> &in2,
                             const coder::array<double, 2U> &in3)
{
  coder::array<double, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  int stride_2_0;
  int stride_2_1;
  if (in3.size(0) == 1) {
    if (in2.size(0) == 1) {
      loop_ub = in1.size(0);
    } else {
      loop_ub = in2.size(0);
    }
  } else {
    loop_ub = in3.size(0);
  }
  if (in3.size(1) == 1) {
    if (in2.size(1) == 1) {
      b_loop_ub = in1.size(1);
    } else {
      b_loop_ub = in2.size(1);
    }
  } else {
    b_loop_ub = in3.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  stride_2_0 = (in3.size(0) != 1);
  stride_2_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          (in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] +
           in2[i1 * stride_1_0 + in2.size(0) * aux_1_1]) -
          in3[i1 * stride_2_0 + in3.size(0) * aux_2_1];
    }
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

//
// Arguments    : double params_Mass
//                const double params_Inertia[9]
//                const double params_AddedMassMatrix[36]
//                double params_NumDoFs
//                double params_Arms_Arm1_Links_Link2_Mass
//                const double params_Arms_Arm1_Links_Link2_InertiaTensor[9]
//                const double params_Arms_Arm1_Links_Link2_AddedMass[36]
//                double params_Arms_Arm1_Links_Link3_Mass
//                const double params_Arms_Arm1_Links_Link3_InertiaTensor[9]
//                const double params_Arms_Arm1_Links_Link3_AddedMass[36]
//                double params_Arms_Arm1_Links_Link4_Mass
//                const double params_Arms_Arm1_Links_Link4_InertiaTensor[9]
//                const double params_Arms_Arm1_Links_Link4_AddedMass[36]
//                double params_Arms_Arm1_Links_Link5_Mass
//                const double params_Arms_Arm1_Links_Link5_InertiaTensor[9]
//                const double params_Arms_Arm1_Links_Link5_AddedMass[36]
//                const struct5_T &params_Arms_Arm2_Links_Link2
//                const struct5_T &params_Arms_Arm2_Links_Link3
//                const struct5_T &params_Arms_Arm2_Links_Link4
//                const struct5_T &params_Arms_Arm2_Links_Link5
//                const double zeta[14]
//                const d_struct_T Kinematics_Jacobians[2]
//                const h_struct_T Kinematics_Transforms[2]
//                coder::array<double, 2U> &C
// Return Type  : void
//
void calculateCoriolisMatrix(
    double params_Mass, const double params_Inertia[9],
    const double params_AddedMassMatrix[36], double params_NumDoFs,
    double params_Arms_Arm1_Links_Link2_Mass,
    const double params_Arms_Arm1_Links_Link2_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link2_AddedMass[36],
    double params_Arms_Arm1_Links_Link3_Mass,
    const double params_Arms_Arm1_Links_Link3_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link3_AddedMass[36],
    double params_Arms_Arm1_Links_Link4_Mass,
    const double params_Arms_Arm1_Links_Link4_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link4_AddedMass[36],
    double params_Arms_Arm1_Links_Link5_Mass,
    const double params_Arms_Arm1_Links_Link5_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link5_AddedMass[36],
    const struct5_T &params_Arms_Arm2_Links_Link2,
    const struct5_T &params_Arms_Arm2_Links_Link3,
    const struct5_T &params_Arms_Arm2_Links_Link4,
    const struct5_T &params_Arms_Arm2_Links_Link5, const double zeta[14],
    const d_struct_T Kinematics_Jacobians[2],
    const h_struct_T Kinematics_Transforms[2], coder::array<double, 2U> &C)
{
  coder::array<double, 2U> J;
  coder::array<double, 2U> Jvehicle;
  coder::array<double, 2U> a;
  coder::array<double, 2U> dJ_dt;
  coder::array<double, 2U> r;
  coder::array<double, 2U> r1;
  coder::array<double, 2U> y;
  b_struct_T jacobian_time_derivatives[2];
  double Wvehicle[36];
  double d[9];
  double v_omega[6];
  double dKv[3];
  double b_d;
  double d1;
  double d2;
  double d3;
  double d4;
  double s;
  int boffset;
  int coffset;
  int k;
  int loop_ub;
  std::memset(&Wvehicle[0], 0, 36U * sizeof(double));
  for (k = 0; k < 6; k++) {
    Wvehicle[k + 6 * k] = 1.0;
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs - 6.0) + 6);
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      Jvehicle[coffset + 6 * j] = Wvehicle[coffset + 6 * j];
    }
  }
  loop_ub = static_cast<int>(params_NumDoFs - 6.0);
  for (int j{0}; j < loop_ub; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      Jvehicle[coffset + 6 * (j + 6)] = 0.0;
    }
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Mass;
  d[4] = params_Mass;
  d[8] = params_Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_AddedMassMatrix[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_AddedMassMatrix[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_AddedMassMatrix[coffset];
    Wvehicle[loop_ub + 3] =
        params_Inertia[3 * j] + params_AddedMassMatrix[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] = d[boffset] + params_AddedMassMatrix[coffset];
    Wvehicle[loop_ub + 1] = params_AddedMassMatrix[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_AddedMassMatrix[coffset];
    Wvehicle[loop_ub + 4] =
        params_Inertia[boffset] + params_AddedMassMatrix[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] = d[boffset] + params_AddedMassMatrix[coffset];
    Wvehicle[loop_ub + 2] = params_AddedMassMatrix[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_AddedMassMatrix[coffset];
    Wvehicle[loop_ub + 5] =
        params_Inertia[boffset] + params_AddedMassMatrix[loop_ub + 5];
  }
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += Jvehicle[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  a.set_size(Jvehicle.size(1), 6);
  loop_ub = Jvehicle.size(1);
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < loop_ub; coffset++) {
      a[coffset + a.size(0) * j] = -Jvehicle[j + 6 * coffset];
    }
  }
  loop_ub = a.size(0);
  y.set_size(a.size(0), 6);
  for (int j{0}; j < 6; j++) {
    coffset = j * loop_ub;
    boffset = j * 6;
    for (int i{0}; i < loop_ub; i++) {
      s = 0.0;
      for (k = 0; k < 6; k++) {
        s += a[k * a.size(0) + i] * Wvehicle[boffset + k];
      }
      y[coffset + i] = s;
    }
  }
  // Mdot = zeros(size(C));
  calculateJacobiansTimeDerivative(zeta, Kinematics_Jacobians,
                                   Kinematics_Transforms,
                                   jacobian_time_derivatives);
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm1_Links_Link2_Mass;
  d[4] = params_Arms_Arm1_Links_Link2_Mass;
  d[8] = params_Arms_Arm1_Links_Link2_Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm1_Links_Link2_AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm1_Links_Link2_AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link2_AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm1_Links_Link2_InertiaTensor[3 * j] +
                            params_Arms_Arm1_Links_Link2_AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link2_AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm1_Links_Link2_AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link2_AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm1_Links_Link2_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link2_AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link2_AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm1_Links_Link2_AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link2_AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm1_Links_Link2_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link2_AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  k = 6 * static_cast<int>(params_NumDoFs);
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[0].Jb.Link2[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link2[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[0].Link2[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 6)] =
          jacobian_time_derivatives[0].Link2[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(y, Jvehicle, C);
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (C.size(0) == r1.size(0)) && (C.size(1) == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm1_Links_Link3_Mass;
  d[4] = params_Arms_Arm1_Links_Link3_Mass;
  d[8] = params_Arms_Arm1_Links_Link3_Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm1_Links_Link3_AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm1_Links_Link3_AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link3_AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm1_Links_Link3_InertiaTensor[3 * j] +
                            params_Arms_Arm1_Links_Link3_AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link3_AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm1_Links_Link3_AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link3_AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm1_Links_Link3_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link3_AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link3_AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm1_Links_Link3_AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link3_AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm1_Links_Link3_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link3_AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[0].Jb.Link3[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link3[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[0].Link3[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 6)] =
          jacobian_time_derivatives[0].Link3[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if (C.size(0) == 1) {
    loop_ub = r.size(0);
  } else {
    loop_ub = C.size(0);
  }
  if (C.size(1) == 1) {
    boffset = r.size(1);
  } else {
    boffset = C.size(1);
  }
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (loop_ub == r1.size(0)) && (boffset == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm1_Links_Link4_Mass;
  d[4] = params_Arms_Arm1_Links_Link4_Mass;
  d[8] = params_Arms_Arm1_Links_Link4_Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm1_Links_Link4_AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm1_Links_Link4_AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link4_AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm1_Links_Link4_InertiaTensor[3 * j] +
                            params_Arms_Arm1_Links_Link4_AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link4_AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm1_Links_Link4_AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link4_AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm1_Links_Link4_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link4_AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link4_AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm1_Links_Link4_AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link4_AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm1_Links_Link4_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link4_AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[0].Jb.Link4[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link4[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[0].Link4[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 6)] =
          jacobian_time_derivatives[0].Link4[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if (C.size(0) == 1) {
    loop_ub = r.size(0);
  } else {
    loop_ub = C.size(0);
  }
  if (C.size(1) == 1) {
    boffset = r.size(1);
  } else {
    boffset = C.size(1);
  }
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (loop_ub == r1.size(0)) && (boffset == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm1_Links_Link5_Mass;
  d[4] = params_Arms_Arm1_Links_Link5_Mass;
  d[8] = params_Arms_Arm1_Links_Link5_Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm1_Links_Link5_AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm1_Links_Link5_AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link5_AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm1_Links_Link5_InertiaTensor[3 * j] +
                            params_Arms_Arm1_Links_Link5_AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link5_AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm1_Links_Link5_AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link5_AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm1_Links_Link5_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link5_AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm1_Links_Link5_AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm1_Links_Link5_AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm1_Links_Link5_AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm1_Links_Link5_InertiaTensor[boffset] +
        params_Arms_Arm1_Links_Link5_AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[0].Jb.Link5[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link5[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[0].Link5[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 6)] =
          jacobian_time_derivatives[0].Link5[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if (C.size(0) == 1) {
    loop_ub = r.size(0);
  } else {
    loop_ub = C.size(0);
  }
  if (C.size(1) == 1) {
    boffset = r.size(1);
  } else {
    boffset = C.size(1);
  }
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (loop_ub == r1.size(0)) && (boffset == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm2_Links_Link2.Mass;
  d[4] = params_Arms_Arm2_Links_Link2.Mass;
  d[8] = params_Arms_Arm2_Links_Link2.Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm2_Links_Link2.AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm2_Links_Link2.AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link2.AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm2_Links_Link2.InertiaTensor[3 * j] +
                            params_Arms_Arm2_Links_Link2.AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link2.AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm2_Links_Link2.AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link2.AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm2_Links_Link2.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link2.AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link2.AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm2_Links_Link2.AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link2.AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm2_Links_Link2.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link2.AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[1].Jb.Link2[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link2[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[1].Link2[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 10)] =
          jacobian_time_derivatives[1].Link2[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if (C.size(0) == 1) {
    loop_ub = r.size(0);
  } else {
    loop_ub = C.size(0);
  }
  if (C.size(1) == 1) {
    boffset = r.size(1);
  } else {
    boffset = C.size(1);
  }
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (loop_ub == r1.size(0)) && (boffset == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm2_Links_Link3.Mass;
  d[4] = params_Arms_Arm2_Links_Link3.Mass;
  d[8] = params_Arms_Arm2_Links_Link3.Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm2_Links_Link3.AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm2_Links_Link3.AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link3.AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm2_Links_Link3.InertiaTensor[3 * j] +
                            params_Arms_Arm2_Links_Link3.AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link3.AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm2_Links_Link3.AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link3.AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm2_Links_Link3.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link3.AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link3.AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm2_Links_Link3.AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link3.AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm2_Links_Link3.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link3.AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[1].Jb.Link3[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link3[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[1].Link3[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 10)] =
          jacobian_time_derivatives[1].Link3[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if (C.size(0) == 1) {
    loop_ub = r.size(0);
  } else {
    loop_ub = C.size(0);
  }
  if (C.size(1) == 1) {
    boffset = r.size(1);
  } else {
    boffset = C.size(1);
  }
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (loop_ub == r1.size(0)) && (boffset == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm2_Links_Link4.Mass;
  d[4] = params_Arms_Arm2_Links_Link4.Mass;
  d[8] = params_Arms_Arm2_Links_Link4.Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm2_Links_Link4.AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm2_Links_Link4.AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link4.AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm2_Links_Link4.InertiaTensor[3 * j] +
                            params_Arms_Arm2_Links_Link4.AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link4.AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm2_Links_Link4.AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link4.AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm2_Links_Link4.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link4.AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link4.AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm2_Links_Link4.AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link4.AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm2_Links_Link4.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link4.AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[1].Jb.Link4[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link4[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[1].Link4[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 10)] =
          jacobian_time_derivatives[1].Link4[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if (C.size(0) == 1) {
    loop_ub = r.size(0);
  } else {
    loop_ub = C.size(0);
  }
  if (C.size(1) == 1) {
    boffset = r.size(1);
  } else {
    boffset = C.size(1);
  }
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (loop_ub == r1.size(0)) && (boffset == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  std::memset(&d[0], 0, 9U * sizeof(double));
  d[0] = params_Arms_Arm2_Links_Link5.Mass;
  d[4] = params_Arms_Arm2_Links_Link5.Mass;
  d[8] = params_Arms_Arm2_Links_Link5.Mass;
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = d[3 * j] + params_Arms_Arm2_Links_Link5.AddedMass[6 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = params_Arms_Arm2_Links_Link5.AddedMass[loop_ub];
    coffset = 6 * j + 3;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link5.AddedMass[coffset];
    Wvehicle[loop_ub + 3] = params_Arms_Arm2_Links_Link5.InertiaTensor[3 * j] +
                            params_Arms_Arm2_Links_Link5.AddedMass[loop_ub + 3];
    coffset = 6 * j + 1;
    boffset = 3 * j + 1;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link5.AddedMass[coffset];
    Wvehicle[loop_ub + 1] = params_Arms_Arm2_Links_Link5.AddedMass[loop_ub + 1];
    coffset = 6 * j + 4;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link5.AddedMass[coffset];
    Wvehicle[loop_ub + 4] =
        params_Arms_Arm2_Links_Link5.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link5.AddedMass[loop_ub + 4];
    coffset = 6 * j + 2;
    boffset = 3 * j + 2;
    Wvehicle[coffset] =
        d[boffset] + params_Arms_Arm2_Links_Link5.AddedMass[coffset];
    Wvehicle[loop_ub + 2] = params_Arms_Arm2_Links_Link5.AddedMass[loop_ub + 2];
    coffset = 6 * j + 5;
    Wvehicle[coffset] = params_Arms_Arm2_Links_Link5.AddedMass[coffset];
    Wvehicle[loop_ub + 5] =
        params_Arms_Arm2_Links_Link5.InertiaTensor[boffset] +
        params_Arms_Arm2_Links_Link5.AddedMass[loop_ub + 5];
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * j] = Kinematics_Jacobians[1].Jb.Link5[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      J[coffset + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link5[coffset + 6 * (j + 6)];
    }
  }
  dJ_dt.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < k; j++) {
    dJ_dt[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * j] =
          jacobian_time_derivatives[1].Link5[coffset + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset = 0; coffset < 6; coffset++) {
      dJ_dt[coffset + 6 * (j + 10)] =
          jacobian_time_derivatives[1].Link5[coffset + 6 * (j + 6)];
    }
  }
  // Mdot = Mdot + dJ_dt'*I*J + J'*I*dJ_dt;
  for (int j{0}; j < 6; j++) {
    s = 0.0;
    for (coffset = 0; coffset < 14; coffset++) {
      s += J[j + 6 * coffset] * zeta[coffset];
    }
    v_omega[j] = s;
  }
  s = v_omega[0];
  b_d = v_omega[1];
  d1 = v_omega[2];
  d2 = v_omega[3];
  d3 = v_omega[4];
  d4 = v_omega[5];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j] * s + Wvehicle[j + 6] * b_d) + Wvehicle[j + 12] * d1) -
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  d[0] = 0.0;
  d[3] = -dKv[2];
  d[6] = dKv[1];
  d[1] = dKv[2];
  d[4] = 0.0;
  d[7] = -dKv[0];
  d[2] = -dKv[1];
  d[5] = dKv[0];
  d[8] = 0.0;
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  s = v_omega[3];
  b_d = v_omega[4];
  d1 = v_omega[5];
  d2 = v_omega[0];
  d3 = v_omega[1];
  d4 = v_omega[2];
  for (int j{0}; j < 3; j++) {
    dKv[j] =
        ((Wvehicle[j + 21] * s + Wvehicle[j + 27] * b_d) +
         Wvehicle[j + 33] * d1) +
        ((Wvehicle[j + 3] * d2 + Wvehicle[j + 9] * d3) + Wvehicle[j + 15] * d4);
  }
  //  Create the skew-symmetric matrix
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, dJ_dt, r);
  for (int j{0}; j < 3; j++) {
    Wvehicle[6 * j] = 0.0;
    s = d[3 * j];
    loop_ub = 6 * (j + 3);
    Wvehicle[loop_ub] = s;
    Wvehicle[6 * j + 3] = s;
    Wvehicle[6 * j + 1] = 0.0;
    s = d[3 * j + 1];
    Wvehicle[loop_ub + 1] = s;
    Wvehicle[6 * j + 4] = s;
    Wvehicle[6 * j + 2] = 0.0;
    s = d[3 * j + 2];
    Wvehicle[loop_ub + 2] = s;
    Wvehicle[6 * j + 5] = s;
  }
  Wvehicle[21] = 0.0;
  Wvehicle[27] = -dKv[2];
  Wvehicle[33] = dKv[1];
  Wvehicle[22] = dKv[2];
  Wvehicle[28] = 0.0;
  Wvehicle[34] = -dKv[0];
  Wvehicle[23] = -dKv[1];
  Wvehicle[29] = dKv[0];
  Wvehicle[35] = 0.0;
  coder::internal::blas::mtimes(J, Wvehicle, a);
  coder::internal::blas::mtimes(a, J, r1);
  if (C.size(0) == 1) {
    loop_ub = r.size(0);
  } else {
    loop_ub = C.size(0);
  }
  if (C.size(1) == 1) {
    boffset = r.size(1);
  } else {
    boffset = C.size(1);
  }
  if ((C.size(0) == r.size(0)) && (C.size(1) == r.size(1)) &&
      (loop_ub == r1.size(0)) && (boffset == r1.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (int j{0}; j < loop_ub; j++) {
      C[j] = (C[j] + r[j]) - r1[j];
    }
  } else {
    binary_expand_op(C, r, r1);
  }
  // SK=Mdot-2*C;
  // disp(issymmetric(SK,"skew"))
}

//
// File trailer for calculateCoriolisMatrix.cpp
//
// [EOF]
//
