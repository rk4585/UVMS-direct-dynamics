//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateJacobiansTimeDerivative.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef CALCULATEJACOBIANSTIMEDERIVATIVE_H
#define CALCULATEJACOBIANSTIMEDERIVATIVE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct d_struct_T;

struct h_struct_T;

struct b_struct_T;

// Function Declarations
void calculateJacobiansTimeDerivative(const double zeta[14],
                                      const d_struct_T Kinematics_Jacobians[2],
                                      const h_struct_T Kinematics_Transforms[2],
                                      b_struct_T dJbi_dts[2]);

#endif
//
// File trailer for calculateJacobiansTimeDerivative.h
//
// [EOF]
//
