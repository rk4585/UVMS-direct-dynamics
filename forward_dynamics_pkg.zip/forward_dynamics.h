//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef FORWARD_DYNAMICS_H
#define FORWARD_DYNAMICS_H

// Include Files
#include "forward_dynamics_types.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void forward_dynamics(const struct0_T *params, const double ksi[14],
                             const double zeta[14],
                             const double control_input[15], double dksi_dt[14],
                             double dzeta_dt_data[], int dzeta_dt_size[1]);

#endif
//
// File trailer for forward_dynamics.h
//
// [EOF]
//
