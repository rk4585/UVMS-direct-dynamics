//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateTransforms.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef CALCULATETRANSFORMS_H
#define CALCULATETRANSFORMS_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct h_struct_T;

// Function Declarations
void calculateTransforms(
    const double params_Arms_Arm1_TransformVehicleToArmBase[16],
    const double params_Arms_Arm1_LastLinkToEE[16],
    const double params_Arms_Arm1_DHParameters_d[5],
    const double params_Arms_Arm1_DHParameters_theta[5],
    const double params_Arms_Arm1_DHParameters_a[5],
    const double params_Arms_Arm1_DHParameters_alpha[5],
    const double params_Arms_Arm2_TransformVehicleToArmBase[16],
    const double params_Arms_Arm2_LastLinkToEE[16],
    const double params_Arms_Arm2_DHParameters_d[5],
    const double params_Arms_Arm2_DHParameters_theta[5],
    const double params_Arms_Arm2_DHParameters_a[5],
    const double params_Arms_Arm2_DHParameters_alpha[5], const double ksi[14],
    h_struct_T transforms[2]);

#endif
//
// File trailer for calculateTransforms.h
//
// [EOF]
//
