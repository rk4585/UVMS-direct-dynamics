//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics_initialize.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "forward_dynamics_initialize.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void forward_dynamics_initialize()
{
}

//
// File trailer for forward_dynamics_initialize.cpp
//
// [EOF]
//
