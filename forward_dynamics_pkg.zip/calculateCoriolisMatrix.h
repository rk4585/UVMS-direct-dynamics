//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateCoriolisMatrix.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef CALCULATECORIOLISMATRIX_H
#define CALCULATECORIOLISMATRIX_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct struct5_T;

struct d_struct_T;

struct h_struct_T;

// Function Declarations
void calculateCoriolisMatrix(
    double params_Mass, const double params_Inertia[9],
    const double params_AddedMassMatrix[36], double params_NumDoFs,
    double params_Arms_Arm1_Links_Link2_Mass,
    const double params_Arms_Arm1_Links_Link2_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link2_AddedMass[36],
    double params_Arms_Arm1_Links_Link3_Mass,
    const double params_Arms_Arm1_Links_Link3_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link3_AddedMass[36],
    double params_Arms_Arm1_Links_Link4_Mass,
    const double params_Arms_Arm1_Links_Link4_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link4_AddedMass[36],
    double params_Arms_Arm1_Links_Link5_Mass,
    const double params_Arms_Arm1_Links_Link5_InertiaTensor[9],
    const double params_Arms_Arm1_Links_Link5_AddedMass[36],
    const struct5_T &params_Arms_Arm2_Links_Link2,
    const struct5_T &params_Arms_Arm2_Links_Link3,
    const struct5_T &params_Arms_Arm2_Links_Link4,
    const struct5_T &params_Arms_Arm2_Links_Link5, const double zeta[14],
    const d_struct_T Kinematics_Jacobians[2],
    const h_struct_T Kinematics_Transforms[2], coder::array<double, 2U> &C);

#endif
//
// File trailer for calculateCoriolisMatrix.h
//
// [EOF]
//
