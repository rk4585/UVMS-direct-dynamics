//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateTransforms.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "calculateTransforms.h"
#include "calculateArmTransforms.h"
#include "forward_dynamics_internal_types.h"
#include "mpower.h"
#include <algorithm>
#include <cmath>

// Function Definitions
//
// Arguments    : const double params_Arms_Arm1_TransformVehicleToArmBase[16]
//                const double params_Arms_Arm1_LastLinkToEE[16]
//                const double params_Arms_Arm1_DHParameters_d[5]
//                const double params_Arms_Arm1_DHParameters_theta[5]
//                const double params_Arms_Arm1_DHParameters_a[5]
//                const double params_Arms_Arm1_DHParameters_alpha[5]
//                const double params_Arms_Arm2_TransformVehicleToArmBase[16]
//                const double params_Arms_Arm2_LastLinkToEE[16]
//                const double params_Arms_Arm2_DHParameters_d[5]
//                const double params_Arms_Arm2_DHParameters_theta[5]
//                const double params_Arms_Arm2_DHParameters_a[5]
//                const double params_Arms_Arm2_DHParameters_alpha[5]
//                const double ksi[14]
//                h_struct_T transforms[2]
// Return Type  : void
//
void calculateTransforms(
    const double params_Arms_Arm1_TransformVehicleToArmBase[16],
    const double params_Arms_Arm1_LastLinkToEE[16],
    const double params_Arms_Arm1_DHParameters_d[5],
    const double params_Arms_Arm1_DHParameters_theta[5],
    const double params_Arms_Arm1_DHParameters_a[5],
    const double params_Arms_Arm1_DHParameters_alpha[5],
    const double params_Arms_Arm2_TransformVehicleToArmBase[16],
    const double params_Arms_Arm2_LastLinkToEE[16],
    const double params_Arms_Arm2_DHParameters_d[5],
    const double params_Arms_Arm2_DHParameters_theta[5],
    const double params_Arms_Arm2_DHParameters_a[5],
    const double params_Arms_Arm2_DHParameters_alpha[5], const double ksi[14],
    h_struct_T transforms[2])
{
  static const double dv1[16]{1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
                              0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0};
  static const signed char b_iv[3]{1, 0, 0};
  e_struct_T R0is[2];
  e_struct_T Rbis[2];
  f_struct_T g0is[2];
  f_struct_T gbis[2];
  g_struct_T Adg0is[2];
  g_struct_T Adgbi_invs[2];
  g_struct_T Adgbis[2];
  struct_T p0is[2];
  struct_T pbis[2];
  double b_gbis[36];
  double g0b[16];
  double c_Ry_tmp[9];
  double c_Rz_tmp[9];
  double d_Rz_tmp[9];
  double dv[9];
  double Rx_tmp;
  double Ry_tmp;
  double Rz_tmp;
  double b_Rx_tmp;
  double b_Ry_tmp;
  double b_Rz_tmp;
  int b_gbis_tmp;
  int g0b_tmp;
  int gbis_tmp;
  Rx_tmp = std::sin(ksi[3]);
  b_Rx_tmp = std::cos(ksi[3]);
  Ry_tmp = std::sin(ksi[4]);
  b_Ry_tmp = std::cos(ksi[4]);
  Rz_tmp = std::sin(ksi[5]);
  b_Rz_tmp = std::cos(ksi[5]);
  c_Rz_tmp[0] = b_Rz_tmp;
  c_Rz_tmp[3] = -Rz_tmp;
  c_Rz_tmp[6] = 0.0;
  c_Rz_tmp[1] = Rz_tmp;
  c_Rz_tmp[4] = b_Rz_tmp;
  c_Rz_tmp[7] = 0.0;
  c_Ry_tmp[0] = b_Ry_tmp;
  c_Ry_tmp[3] = 0.0;
  c_Ry_tmp[6] = Ry_tmp;
  c_Rz_tmp[2] = 0.0;
  c_Ry_tmp[1] = 0.0;
  c_Rz_tmp[5] = 0.0;
  c_Ry_tmp[4] = 1.0;
  c_Rz_tmp[8] = 1.0;
  c_Ry_tmp[7] = 0.0;
  c_Ry_tmp[2] = -Ry_tmp;
  c_Ry_tmp[5] = 0.0;
  c_Ry_tmp[8] = b_Ry_tmp;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = c_Rz_tmp[i];
    b_Rz_tmp = c_Rz_tmp[i + 3];
    g0b_tmp = static_cast<int>(c_Rz_tmp[i + 6]);
    for (gbis_tmp = 0; gbis_tmp < 3; gbis_tmp++) {
      d_Rz_tmp[i + 3 * gbis_tmp] =
          (Rz_tmp * c_Ry_tmp[3 * gbis_tmp] +
           b_Rz_tmp * c_Ry_tmp[3 * gbis_tmp + 1]) +
          static_cast<double>(g0b_tmp) * c_Ry_tmp[3 * gbis_tmp + 2];
    }
    dv[3 * i] = b_iv[i];
  }
  dv[1] = 0.0;
  dv[4] = b_Rx_tmp;
  dv[7] = -Rx_tmp;
  dv[2] = 0.0;
  dv[5] = Rx_tmp;
  dv[8] = b_Rx_tmp;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = d_Rz_tmp[i];
    b_Rz_tmp = d_Rz_tmp[i + 3];
    Ry_tmp = d_Rz_tmp[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      c_Rz_tmp[i + 3 * g0b_tmp] =
          (Rz_tmp * dv[3 * g0b_tmp] + b_Rz_tmp * dv[3 * g0b_tmp + 1]) +
          Ry_tmp * dv[3 * g0b_tmp + 2];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = i << 2;
    g0b[g0b_tmp] = c_Rz_tmp[3 * i];
    g0b[g0b_tmp + 1] = c_Rz_tmp[3 * i + 1];
    g0b[g0b_tmp + 2] = c_Rz_tmp[3 * i + 2];
    g0b[i + 12] = ksi[i];
  }
  g0b[3] = 0.0;
  g0b[7] = 0.0;
  g0b[11] = 0.0;
  g0b[15] = 1.0;
  calculateArmTransforms(
      params_Arms_Arm1_TransformVehicleToArmBase, params_Arms_Arm1_LastLinkToEE,
      params_Arms_Arm1_DHParameters_d, params_Arms_Arm1_DHParameters_theta,
      params_Arms_Arm1_DHParameters_a, params_Arms_Arm1_DHParameters_alpha, ksi,
      dv1, gbis[1].Link1, gbis[1].Link2, gbis[1].Link3, gbis[1].Link4,
      gbis[1].Link5, gbis[1].EE);
  calculateArmTransforms(
      params_Arms_Arm1_TransformVehicleToArmBase, params_Arms_Arm1_LastLinkToEE,
      params_Arms_Arm1_DHParameters_d, params_Arms_Arm1_DHParameters_theta,
      params_Arms_Arm1_DHParameters_a, params_Arms_Arm1_DHParameters_alpha, ksi,
      g0b, g0is[1].Link1, g0is[1].Link2, g0is[1].Link3, g0is[1].Link4,
      g0is[1].Link5, g0is[1].EE);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link1[14];
  dv[6] = gbis[1].Link1[13];
  dv[1] = gbis[1].Link1[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link1[12];
  dv[2] = -gbis[1].Link1[13];
  dv[5] = gbis[1].Link1[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    pbis[1].Link1[i] = gbis[1].Link1[i + 12];
    p0is[1].Link1[i] = g0is[1].Link1[i + 12];
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp + (i << 2);
      b_gbis_tmp = g0b_tmp + 3 * i;
      b_Ry_tmp = gbis[1].Link1[gbis_tmp];
      Rbis[1].Link1[b_gbis_tmp] = b_Ry_tmp;
      R0is[1].Link1[b_gbis_tmp] = g0is[1].Link1[gbis_tmp];
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link1[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link1[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link1[gbis_tmp + 2];
      Adgbis[1].Link1[g0b_tmp + 6 * i] = b_Ry_tmp;
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link1[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link1[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link1[g0b_tmp + 3] = gbis[1].Link1[gbis_tmp];
    Adgbis[1].Link1[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link1[6 * i + 4] = 0.0;
    Adgbis[1].Link1[g0b_tmp + 4] = gbis[1].Link1[gbis_tmp + 1];
    Adgbis[1].Link1[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link1[6 * i + 5] = 0.0;
    Adgbis[1].Link1[g0b_tmp + 5] = gbis[1].Link1[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link1[14];
  dv[6] = g0is[1].Link1[13];
  dv[1] = g0is[1].Link1[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link1[12];
  dv[2] = -g0is[1].Link1[13];
  dv[5] = g0is[1].Link1[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link1[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link1[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link1[gbis_tmp + 2];
      Adg0is[1].Link1[g0b_tmp + 6 * i] = g0is[1].Link1[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link1[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link1[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link1[g0b_tmp + 3] = g0is[1].Link1[gbis_tmp];
    Adg0is[1].Link1[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link1[6 * i + 4] = 0.0;
    Adg0is[1].Link1[g0b_tmp + 4] = g0is[1].Link1[gbis_tmp + 1];
    Adg0is[1].Link1[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link1[6 * i + 5] = 0.0;
    Adg0is[1].Link1[g0b_tmp + 5] = g0is[1].Link1[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link1[14];
  dv[6] = gbis[1].Link1[13];
  dv[1] = gbis[1].Link1[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link1[12];
  dv[2] = -gbis[1].Link1[13];
  dv[5] = gbis[1].Link1[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link1[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link1[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link1[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link1[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link2[i] = gbis[1].Link2[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link1[gbis_tmp];
    Rbis[1].Link2[3 * i] = gbis[1].Link2[gbis_tmp];
    R0is[1].Link2[3 * i] = g0is[1].Link2[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link1[gbis_tmp + 1];
    Rbis[1].Link2[b_gbis_tmp] = gbis[1].Link2[gbis_tmp + 1];
    R0is[1].Link2[b_gbis_tmp] = g0is[1].Link2[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link1[gbis_tmp + 2];
    Rbis[1].Link2[b_gbis_tmp] = gbis[1].Link2[gbis_tmp + 2];
    R0is[1].Link2[b_gbis_tmp] = g0is[1].Link2[gbis_tmp + 2];
    p0is[1].Link2[i] = g0is[1].Link2[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link1);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link2[14];
  dv[6] = gbis[1].Link2[13];
  dv[1] = gbis[1].Link2[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link2[12];
  dv[2] = -gbis[1].Link2[13];
  dv[5] = gbis[1].Link2[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link2[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link2[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link2[gbis_tmp + 2];
      Adgbis[1].Link2[g0b_tmp + 6 * i] = gbis[1].Link2[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link2[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link2[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link2[g0b_tmp + 3] = gbis[1].Link2[gbis_tmp];
    Adgbis[1].Link2[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link2[6 * i + 4] = 0.0;
    Adgbis[1].Link2[g0b_tmp + 4] = gbis[1].Link2[gbis_tmp + 1];
    Adgbis[1].Link2[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link2[6 * i + 5] = 0.0;
    Adgbis[1].Link2[g0b_tmp + 5] = gbis[1].Link2[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link2[14];
  dv[6] = g0is[1].Link2[13];
  dv[1] = g0is[1].Link2[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link2[12];
  dv[2] = -g0is[1].Link2[13];
  dv[5] = g0is[1].Link2[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link2[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link2[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link2[gbis_tmp + 2];
      Adg0is[1].Link2[g0b_tmp + 6 * i] = g0is[1].Link2[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link2[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link2[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link2[g0b_tmp + 3] = g0is[1].Link2[gbis_tmp];
    Adg0is[1].Link2[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link2[6 * i + 4] = 0.0;
    Adg0is[1].Link2[g0b_tmp + 4] = g0is[1].Link2[gbis_tmp + 1];
    Adg0is[1].Link2[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link2[6 * i + 5] = 0.0;
    Adg0is[1].Link2[g0b_tmp + 5] = g0is[1].Link2[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link2[14];
  dv[6] = gbis[1].Link2[13];
  dv[1] = gbis[1].Link2[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link2[12];
  dv[2] = -gbis[1].Link2[13];
  dv[5] = gbis[1].Link2[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link2[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link2[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link2[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link2[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link3[i] = gbis[1].Link3[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link2[gbis_tmp];
    Rbis[1].Link3[3 * i] = gbis[1].Link3[gbis_tmp];
    R0is[1].Link3[3 * i] = g0is[1].Link3[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link2[gbis_tmp + 1];
    Rbis[1].Link3[b_gbis_tmp] = gbis[1].Link3[gbis_tmp + 1];
    R0is[1].Link3[b_gbis_tmp] = g0is[1].Link3[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link2[gbis_tmp + 2];
    Rbis[1].Link3[b_gbis_tmp] = gbis[1].Link3[gbis_tmp + 2];
    R0is[1].Link3[b_gbis_tmp] = g0is[1].Link3[gbis_tmp + 2];
    p0is[1].Link3[i] = g0is[1].Link3[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link2);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link3[14];
  dv[6] = gbis[1].Link3[13];
  dv[1] = gbis[1].Link3[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link3[12];
  dv[2] = -gbis[1].Link3[13];
  dv[5] = gbis[1].Link3[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link3[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link3[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link3[gbis_tmp + 2];
      Adgbis[1].Link3[g0b_tmp + 6 * i] = gbis[1].Link3[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link3[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link3[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link3[g0b_tmp + 3] = gbis[1].Link3[gbis_tmp];
    Adgbis[1].Link3[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link3[6 * i + 4] = 0.0;
    Adgbis[1].Link3[g0b_tmp + 4] = gbis[1].Link3[gbis_tmp + 1];
    Adgbis[1].Link3[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link3[6 * i + 5] = 0.0;
    Adgbis[1].Link3[g0b_tmp + 5] = gbis[1].Link3[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link3[14];
  dv[6] = g0is[1].Link3[13];
  dv[1] = g0is[1].Link3[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link3[12];
  dv[2] = -g0is[1].Link3[13];
  dv[5] = g0is[1].Link3[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link3[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link3[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link3[gbis_tmp + 2];
      Adg0is[1].Link3[g0b_tmp + 6 * i] = g0is[1].Link3[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link3[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link3[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link3[g0b_tmp + 3] = g0is[1].Link3[gbis_tmp];
    Adg0is[1].Link3[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link3[6 * i + 4] = 0.0;
    Adg0is[1].Link3[g0b_tmp + 4] = g0is[1].Link3[gbis_tmp + 1];
    Adg0is[1].Link3[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link3[6 * i + 5] = 0.0;
    Adg0is[1].Link3[g0b_tmp + 5] = g0is[1].Link3[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link3[14];
  dv[6] = gbis[1].Link3[13];
  dv[1] = gbis[1].Link3[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link3[12];
  dv[2] = -gbis[1].Link3[13];
  dv[5] = gbis[1].Link3[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link3[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link3[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link3[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link3[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link4[i] = gbis[1].Link4[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link3[gbis_tmp];
    Rbis[1].Link4[3 * i] = gbis[1].Link4[gbis_tmp];
    R0is[1].Link4[3 * i] = g0is[1].Link4[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link3[gbis_tmp + 1];
    Rbis[1].Link4[b_gbis_tmp] = gbis[1].Link4[gbis_tmp + 1];
    R0is[1].Link4[b_gbis_tmp] = g0is[1].Link4[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link3[gbis_tmp + 2];
    Rbis[1].Link4[b_gbis_tmp] = gbis[1].Link4[gbis_tmp + 2];
    R0is[1].Link4[b_gbis_tmp] = g0is[1].Link4[gbis_tmp + 2];
    p0is[1].Link4[i] = g0is[1].Link4[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link3);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link4[14];
  dv[6] = gbis[1].Link4[13];
  dv[1] = gbis[1].Link4[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link4[12];
  dv[2] = -gbis[1].Link4[13];
  dv[5] = gbis[1].Link4[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link4[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link4[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link4[gbis_tmp + 2];
      Adgbis[1].Link4[g0b_tmp + 6 * i] = gbis[1].Link4[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link4[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link4[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link4[g0b_tmp + 3] = gbis[1].Link4[gbis_tmp];
    Adgbis[1].Link4[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link4[6 * i + 4] = 0.0;
    Adgbis[1].Link4[g0b_tmp + 4] = gbis[1].Link4[gbis_tmp + 1];
    Adgbis[1].Link4[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link4[6 * i + 5] = 0.0;
    Adgbis[1].Link4[g0b_tmp + 5] = gbis[1].Link4[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link4[14];
  dv[6] = g0is[1].Link4[13];
  dv[1] = g0is[1].Link4[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link4[12];
  dv[2] = -g0is[1].Link4[13];
  dv[5] = g0is[1].Link4[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link4[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link4[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link4[gbis_tmp + 2];
      Adg0is[1].Link4[g0b_tmp + 6 * i] = g0is[1].Link4[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link4[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link4[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link4[g0b_tmp + 3] = g0is[1].Link4[gbis_tmp];
    Adg0is[1].Link4[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link4[6 * i + 4] = 0.0;
    Adg0is[1].Link4[g0b_tmp + 4] = g0is[1].Link4[gbis_tmp + 1];
    Adg0is[1].Link4[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link4[6 * i + 5] = 0.0;
    Adg0is[1].Link4[g0b_tmp + 5] = g0is[1].Link4[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link4[14];
  dv[6] = gbis[1].Link4[13];
  dv[1] = gbis[1].Link4[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link4[12];
  dv[2] = -gbis[1].Link4[13];
  dv[5] = gbis[1].Link4[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link4[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link4[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link4[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link4[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link5[i] = gbis[1].Link5[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link4[gbis_tmp];
    Rbis[1].Link5[3 * i] = gbis[1].Link5[gbis_tmp];
    R0is[1].Link5[3 * i] = g0is[1].Link5[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link4[gbis_tmp + 1];
    Rbis[1].Link5[b_gbis_tmp] = gbis[1].Link5[gbis_tmp + 1];
    R0is[1].Link5[b_gbis_tmp] = g0is[1].Link5[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link4[gbis_tmp + 2];
    Rbis[1].Link5[b_gbis_tmp] = gbis[1].Link5[gbis_tmp + 2];
    R0is[1].Link5[b_gbis_tmp] = g0is[1].Link5[gbis_tmp + 2];
    p0is[1].Link5[i] = g0is[1].Link5[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link4);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link5[14];
  dv[6] = gbis[1].Link5[13];
  dv[1] = gbis[1].Link5[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link5[12];
  dv[2] = -gbis[1].Link5[13];
  dv[5] = gbis[1].Link5[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link5[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link5[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link5[gbis_tmp + 2];
      Adgbis[1].Link5[g0b_tmp + 6 * i] = gbis[1].Link5[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link5[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link5[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link5[g0b_tmp + 3] = gbis[1].Link5[gbis_tmp];
    Adgbis[1].Link5[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link5[6 * i + 4] = 0.0;
    Adgbis[1].Link5[g0b_tmp + 4] = gbis[1].Link5[gbis_tmp + 1];
    Adgbis[1].Link5[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link5[6 * i + 5] = 0.0;
    Adgbis[1].Link5[g0b_tmp + 5] = gbis[1].Link5[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link5[14];
  dv[6] = g0is[1].Link5[13];
  dv[1] = g0is[1].Link5[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link5[12];
  dv[2] = -g0is[1].Link5[13];
  dv[5] = g0is[1].Link5[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link5[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link5[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link5[gbis_tmp + 2];
      Adg0is[1].Link5[g0b_tmp + 6 * i] = g0is[1].Link5[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link5[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link5[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link5[g0b_tmp + 3] = g0is[1].Link5[gbis_tmp];
    Adg0is[1].Link5[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link5[6 * i + 4] = 0.0;
    Adg0is[1].Link5[g0b_tmp + 4] = g0is[1].Link5[gbis_tmp + 1];
    Adg0is[1].Link5[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link5[6 * i + 5] = 0.0;
    Adg0is[1].Link5[g0b_tmp + 5] = g0is[1].Link5[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link5[14];
  dv[6] = gbis[1].Link5[13];
  dv[1] = gbis[1].Link5[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link5[12];
  dv[2] = -gbis[1].Link5[13];
  dv[5] = gbis[1].Link5[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link5[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link5[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link5[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link5[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].EE[i] = gbis[1].EE[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link5[gbis_tmp];
    Rbis[1].EE[3 * i] = gbis[1].EE[gbis_tmp];
    R0is[1].EE[3 * i] = g0is[1].EE[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link5[gbis_tmp + 1];
    Rbis[1].EE[b_gbis_tmp] = gbis[1].EE[gbis_tmp + 1];
    R0is[1].EE[b_gbis_tmp] = g0is[1].EE[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link5[gbis_tmp + 2];
    Rbis[1].EE[b_gbis_tmp] = gbis[1].EE[gbis_tmp + 2];
    R0is[1].EE[b_gbis_tmp] = g0is[1].EE[gbis_tmp + 2];
    p0is[1].EE[i] = g0is[1].EE[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link5);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].EE[14];
  dv[6] = gbis[1].EE[13];
  dv[1] = gbis[1].EE[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].EE[12];
  dv[2] = -gbis[1].EE[13];
  dv[5] = gbis[1].EE[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].EE[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].EE[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].EE[gbis_tmp + 2];
      Adgbis[1].EE[g0b_tmp + 6 * i] = gbis[1].EE[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].EE[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].EE[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].EE[g0b_tmp + 3] = gbis[1].EE[gbis_tmp];
    Adgbis[1].EE[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].EE[6 * i + 4] = 0.0;
    Adgbis[1].EE[g0b_tmp + 4] = gbis[1].EE[gbis_tmp + 1];
    Adgbis[1].EE[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].EE[6 * i + 5] = 0.0;
    Adgbis[1].EE[g0b_tmp + 5] = gbis[1].EE[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].EE[14];
  dv[6] = g0is[1].EE[13];
  dv[1] = g0is[1].EE[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].EE[12];
  dv[2] = -g0is[1].EE[13];
  dv[5] = g0is[1].EE[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].EE[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].EE[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].EE[gbis_tmp + 2];
      Adg0is[1].EE[g0b_tmp + 6 * i] = g0is[1].EE[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].EE[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].EE[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].EE[g0b_tmp + 3] = g0is[1].EE[gbis_tmp];
    Adg0is[1].EE[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].EE[6 * i + 4] = 0.0;
    Adg0is[1].EE[g0b_tmp + 4] = g0is[1].EE[gbis_tmp + 1];
    Adg0is[1].EE[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].EE[6 * i + 5] = 0.0;
    Adg0is[1].EE[g0b_tmp + 5] = g0is[1].EE[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].EE[14];
  dv[6] = gbis[1].EE[13];
  dv[1] = gbis[1].EE[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].EE[12];
  dv[2] = -gbis[1].EE[13];
  dv[5] = gbis[1].EE[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].EE[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].EE[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].EE[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].EE[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].EE[gbis_tmp];
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].EE[gbis_tmp + 1];
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].EE[gbis_tmp + 2];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].EE);
  for (int i{0}; i < 16; i++) {
    gbis[0].Link1[i] = gbis[1].Link1[i];
    gbis[0].Link2[i] = gbis[1].Link2[i];
    gbis[0].Link3[i] = gbis[1].Link3[i];
    gbis[0].Link4[i] = gbis[1].Link4[i];
    gbis[0].Link5[i] = gbis[1].Link5[i];
    gbis[0].EE[i] = gbis[1].EE[i];
    g0is[0].Link1[i] = g0is[1].Link1[i];
    g0is[0].Link2[i] = g0is[1].Link2[i];
    g0is[0].Link3[i] = g0is[1].Link3[i];
    g0is[0].Link4[i] = g0is[1].Link4[i];
    g0is[0].Link5[i] = g0is[1].Link5[i];
    g0is[0].EE[i] = g0is[1].EE[i];
  }
  for (int i{0}; i < 9; i++) {
    Rbis[0].Link1[i] = Rbis[1].Link1[i];
    Rbis[0].Link2[i] = Rbis[1].Link2[i];
    Rbis[0].Link3[i] = Rbis[1].Link3[i];
    Rbis[0].Link4[i] = Rbis[1].Link4[i];
    Rbis[0].Link5[i] = Rbis[1].Link5[i];
    Rbis[0].EE[i] = Rbis[1].EE[i];
    R0is[0].Link1[i] = R0is[1].Link1[i];
    R0is[0].Link2[i] = R0is[1].Link2[i];
    R0is[0].Link3[i] = R0is[1].Link3[i];
    R0is[0].Link4[i] = R0is[1].Link4[i];
    R0is[0].Link5[i] = R0is[1].Link5[i];
    R0is[0].EE[i] = R0is[1].EE[i];
  }
  pbis[0].Link1[0] = pbis[1].Link1[0];
  pbis[0].Link2[0] = pbis[1].Link2[0];
  pbis[0].Link3[0] = pbis[1].Link3[0];
  pbis[0].Link4[0] = pbis[1].Link4[0];
  pbis[0].Link5[0] = pbis[1].Link5[0];
  pbis[0].EE[0] = pbis[1].EE[0];
  p0is[0].Link1[0] = p0is[1].Link1[0];
  p0is[0].Link2[0] = p0is[1].Link2[0];
  p0is[0].Link3[0] = p0is[1].Link3[0];
  p0is[0].Link4[0] = p0is[1].Link4[0];
  p0is[0].Link5[0] = p0is[1].Link5[0];
  p0is[0].EE[0] = p0is[1].EE[0];
  pbis[0].Link1[1] = pbis[1].Link1[1];
  pbis[0].Link2[1] = pbis[1].Link2[1];
  pbis[0].Link3[1] = pbis[1].Link3[1];
  pbis[0].Link4[1] = pbis[1].Link4[1];
  pbis[0].Link5[1] = pbis[1].Link5[1];
  pbis[0].EE[1] = pbis[1].EE[1];
  p0is[0].Link1[1] = p0is[1].Link1[1];
  p0is[0].Link2[1] = p0is[1].Link2[1];
  p0is[0].Link3[1] = p0is[1].Link3[1];
  p0is[0].Link4[1] = p0is[1].Link4[1];
  p0is[0].Link5[1] = p0is[1].Link5[1];
  p0is[0].EE[1] = p0is[1].EE[1];
  pbis[0].Link1[2] = pbis[1].Link1[2];
  pbis[0].Link2[2] = pbis[1].Link2[2];
  pbis[0].Link3[2] = pbis[1].Link3[2];
  pbis[0].Link4[2] = pbis[1].Link4[2];
  pbis[0].Link5[2] = pbis[1].Link5[2];
  pbis[0].EE[2] = pbis[1].EE[2];
  p0is[0].Link1[2] = p0is[1].Link1[2];
  p0is[0].Link2[2] = p0is[1].Link2[2];
  p0is[0].Link3[2] = p0is[1].Link3[2];
  p0is[0].Link4[2] = p0is[1].Link4[2];
  p0is[0].Link5[2] = p0is[1].Link5[2];
  p0is[0].EE[2] = p0is[1].EE[2];
  for (int i{0}; i < 36; i++) {
    Adgbis[0].Link1[i] = Adgbis[1].Link1[i];
    Adgbis[0].Link2[i] = Adgbis[1].Link2[i];
    Adgbis[0].Link3[i] = Adgbis[1].Link3[i];
    Adgbis[0].Link4[i] = Adgbis[1].Link4[i];
    Adgbis[0].Link5[i] = Adgbis[1].Link5[i];
    Adgbis[0].EE[i] = Adgbis[1].EE[i];
    Adg0is[0].Link1[i] = Adg0is[1].Link1[i];
    Adg0is[0].Link2[i] = Adg0is[1].Link2[i];
    Adg0is[0].Link3[i] = Adg0is[1].Link3[i];
    Adg0is[0].Link4[i] = Adg0is[1].Link4[i];
    Adg0is[0].Link5[i] = Adg0is[1].Link5[i];
    Adg0is[0].EE[i] = Adg0is[1].EE[i];
    Adgbi_invs[0].Link1[i] = Adgbi_invs[1].Link1[i];
    Adgbi_invs[0].Link2[i] = Adgbi_invs[1].Link2[i];
    Adgbi_invs[0].Link3[i] = Adgbi_invs[1].Link3[i];
    Adgbi_invs[0].Link4[i] = Adgbi_invs[1].Link4[i];
    Adgbi_invs[0].Link5[i] = Adgbi_invs[1].Link5[i];
    Adgbi_invs[0].EE[i] = Adgbi_invs[1].EE[i];
  }
  b_calculateArmTransforms(
      params_Arms_Arm2_TransformVehicleToArmBase, params_Arms_Arm2_LastLinkToEE,
      params_Arms_Arm2_DHParameters_d, params_Arms_Arm2_DHParameters_theta,
      params_Arms_Arm2_DHParameters_a, params_Arms_Arm2_DHParameters_alpha, ksi,
      dv1, gbis[1].Link1, gbis[1].Link2, gbis[1].Link3, gbis[1].Link4,
      gbis[1].Link5, gbis[1].EE);
  b_calculateArmTransforms(
      params_Arms_Arm2_TransformVehicleToArmBase, params_Arms_Arm2_LastLinkToEE,
      params_Arms_Arm2_DHParameters_d, params_Arms_Arm2_DHParameters_theta,
      params_Arms_Arm2_DHParameters_a, params_Arms_Arm2_DHParameters_alpha, ksi,
      g0b, g0is[1].Link1, g0is[1].Link2, g0is[1].Link3, g0is[1].Link4,
      g0is[1].Link5, g0is[1].EE);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link1[14];
  dv[6] = gbis[1].Link1[13];
  dv[1] = gbis[1].Link1[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link1[12];
  dv[2] = -gbis[1].Link1[13];
  dv[5] = gbis[1].Link1[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    pbis[1].Link1[i] = gbis[1].Link1[i + 12];
    p0is[1].Link1[i] = g0is[1].Link1[i + 12];
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp + (i << 2);
      b_gbis_tmp = g0b_tmp + 3 * i;
      b_Ry_tmp = gbis[1].Link1[gbis_tmp];
      Rbis[1].Link1[b_gbis_tmp] = b_Ry_tmp;
      R0is[1].Link1[b_gbis_tmp] = g0is[1].Link1[gbis_tmp];
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link1[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link1[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link1[gbis_tmp + 2];
      Adgbis[1].Link1[g0b_tmp + 6 * i] = b_Ry_tmp;
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link1[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link1[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link1[g0b_tmp + 3] = gbis[1].Link1[gbis_tmp];
    Adgbis[1].Link1[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link1[6 * i + 4] = 0.0;
    Adgbis[1].Link1[g0b_tmp + 4] = gbis[1].Link1[gbis_tmp + 1];
    Adgbis[1].Link1[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link1[6 * i + 5] = 0.0;
    Adgbis[1].Link1[g0b_tmp + 5] = gbis[1].Link1[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link1[14];
  dv[6] = g0is[1].Link1[13];
  dv[1] = g0is[1].Link1[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link1[12];
  dv[2] = -g0is[1].Link1[13];
  dv[5] = g0is[1].Link1[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link1[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link1[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link1[gbis_tmp + 2];
      Adg0is[1].Link1[g0b_tmp + 6 * i] = g0is[1].Link1[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link1[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link1[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link1[g0b_tmp + 3] = g0is[1].Link1[gbis_tmp];
    Adg0is[1].Link1[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link1[6 * i + 4] = 0.0;
    Adg0is[1].Link1[g0b_tmp + 4] = g0is[1].Link1[gbis_tmp + 1];
    Adg0is[1].Link1[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link1[6 * i + 5] = 0.0;
    Adg0is[1].Link1[g0b_tmp + 5] = g0is[1].Link1[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link1[14];
  dv[6] = gbis[1].Link1[13];
  dv[1] = gbis[1].Link1[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link1[12];
  dv[2] = -gbis[1].Link1[13];
  dv[5] = gbis[1].Link1[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link1[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link1[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link1[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link1[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link2[i] = gbis[1].Link2[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link1[gbis_tmp];
    Rbis[1].Link2[3 * i] = gbis[1].Link2[gbis_tmp];
    R0is[1].Link2[3 * i] = g0is[1].Link2[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link1[gbis_tmp + 1];
    Rbis[1].Link2[b_gbis_tmp] = gbis[1].Link2[gbis_tmp + 1];
    R0is[1].Link2[b_gbis_tmp] = g0is[1].Link2[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link1[gbis_tmp + 2];
    Rbis[1].Link2[b_gbis_tmp] = gbis[1].Link2[gbis_tmp + 2];
    R0is[1].Link2[b_gbis_tmp] = g0is[1].Link2[gbis_tmp + 2];
    p0is[1].Link2[i] = g0is[1].Link2[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link1);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link2[14];
  dv[6] = gbis[1].Link2[13];
  dv[1] = gbis[1].Link2[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link2[12];
  dv[2] = -gbis[1].Link2[13];
  dv[5] = gbis[1].Link2[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link2[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link2[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link2[gbis_tmp + 2];
      Adgbis[1].Link2[g0b_tmp + 6 * i] = gbis[1].Link2[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link2[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link2[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link2[g0b_tmp + 3] = gbis[1].Link2[gbis_tmp];
    Adgbis[1].Link2[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link2[6 * i + 4] = 0.0;
    Adgbis[1].Link2[g0b_tmp + 4] = gbis[1].Link2[gbis_tmp + 1];
    Adgbis[1].Link2[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link2[6 * i + 5] = 0.0;
    Adgbis[1].Link2[g0b_tmp + 5] = gbis[1].Link2[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link2[14];
  dv[6] = g0is[1].Link2[13];
  dv[1] = g0is[1].Link2[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link2[12];
  dv[2] = -g0is[1].Link2[13];
  dv[5] = g0is[1].Link2[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link2[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link2[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link2[gbis_tmp + 2];
      Adg0is[1].Link2[g0b_tmp + 6 * i] = g0is[1].Link2[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link2[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link2[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link2[g0b_tmp + 3] = g0is[1].Link2[gbis_tmp];
    Adg0is[1].Link2[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link2[6 * i + 4] = 0.0;
    Adg0is[1].Link2[g0b_tmp + 4] = g0is[1].Link2[gbis_tmp + 1];
    Adg0is[1].Link2[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link2[6 * i + 5] = 0.0;
    Adg0is[1].Link2[g0b_tmp + 5] = g0is[1].Link2[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link2[14];
  dv[6] = gbis[1].Link2[13];
  dv[1] = gbis[1].Link2[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link2[12];
  dv[2] = -gbis[1].Link2[13];
  dv[5] = gbis[1].Link2[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link2[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link2[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link2[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link2[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link3[i] = gbis[1].Link3[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link2[gbis_tmp];
    Rbis[1].Link3[3 * i] = gbis[1].Link3[gbis_tmp];
    R0is[1].Link3[3 * i] = g0is[1].Link3[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link2[gbis_tmp + 1];
    Rbis[1].Link3[b_gbis_tmp] = gbis[1].Link3[gbis_tmp + 1];
    R0is[1].Link3[b_gbis_tmp] = g0is[1].Link3[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link2[gbis_tmp + 2];
    Rbis[1].Link3[b_gbis_tmp] = gbis[1].Link3[gbis_tmp + 2];
    R0is[1].Link3[b_gbis_tmp] = g0is[1].Link3[gbis_tmp + 2];
    p0is[1].Link3[i] = g0is[1].Link3[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link2);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link3[14];
  dv[6] = gbis[1].Link3[13];
  dv[1] = gbis[1].Link3[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link3[12];
  dv[2] = -gbis[1].Link3[13];
  dv[5] = gbis[1].Link3[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link3[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link3[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link3[gbis_tmp + 2];
      Adgbis[1].Link3[g0b_tmp + 6 * i] = gbis[1].Link3[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link3[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link3[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link3[g0b_tmp + 3] = gbis[1].Link3[gbis_tmp];
    Adgbis[1].Link3[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link3[6 * i + 4] = 0.0;
    Adgbis[1].Link3[g0b_tmp + 4] = gbis[1].Link3[gbis_tmp + 1];
    Adgbis[1].Link3[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link3[6 * i + 5] = 0.0;
    Adgbis[1].Link3[g0b_tmp + 5] = gbis[1].Link3[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link3[14];
  dv[6] = g0is[1].Link3[13];
  dv[1] = g0is[1].Link3[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link3[12];
  dv[2] = -g0is[1].Link3[13];
  dv[5] = g0is[1].Link3[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link3[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link3[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link3[gbis_tmp + 2];
      Adg0is[1].Link3[g0b_tmp + 6 * i] = g0is[1].Link3[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link3[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link3[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link3[g0b_tmp + 3] = g0is[1].Link3[gbis_tmp];
    Adg0is[1].Link3[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link3[6 * i + 4] = 0.0;
    Adg0is[1].Link3[g0b_tmp + 4] = g0is[1].Link3[gbis_tmp + 1];
    Adg0is[1].Link3[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link3[6 * i + 5] = 0.0;
    Adg0is[1].Link3[g0b_tmp + 5] = g0is[1].Link3[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link3[14];
  dv[6] = gbis[1].Link3[13];
  dv[1] = gbis[1].Link3[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link3[12];
  dv[2] = -gbis[1].Link3[13];
  dv[5] = gbis[1].Link3[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link3[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link3[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link3[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link3[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link4[i] = gbis[1].Link4[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link3[gbis_tmp];
    Rbis[1].Link4[3 * i] = gbis[1].Link4[gbis_tmp];
    R0is[1].Link4[3 * i] = g0is[1].Link4[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link3[gbis_tmp + 1];
    Rbis[1].Link4[b_gbis_tmp] = gbis[1].Link4[gbis_tmp + 1];
    R0is[1].Link4[b_gbis_tmp] = g0is[1].Link4[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link3[gbis_tmp + 2];
    Rbis[1].Link4[b_gbis_tmp] = gbis[1].Link4[gbis_tmp + 2];
    R0is[1].Link4[b_gbis_tmp] = g0is[1].Link4[gbis_tmp + 2];
    p0is[1].Link4[i] = g0is[1].Link4[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link3);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link4[14];
  dv[6] = gbis[1].Link4[13];
  dv[1] = gbis[1].Link4[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link4[12];
  dv[2] = -gbis[1].Link4[13];
  dv[5] = gbis[1].Link4[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link4[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link4[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link4[gbis_tmp + 2];
      Adgbis[1].Link4[g0b_tmp + 6 * i] = gbis[1].Link4[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link4[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link4[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link4[g0b_tmp + 3] = gbis[1].Link4[gbis_tmp];
    Adgbis[1].Link4[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link4[6 * i + 4] = 0.0;
    Adgbis[1].Link4[g0b_tmp + 4] = gbis[1].Link4[gbis_tmp + 1];
    Adgbis[1].Link4[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link4[6 * i + 5] = 0.0;
    Adgbis[1].Link4[g0b_tmp + 5] = gbis[1].Link4[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link4[14];
  dv[6] = g0is[1].Link4[13];
  dv[1] = g0is[1].Link4[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link4[12];
  dv[2] = -g0is[1].Link4[13];
  dv[5] = g0is[1].Link4[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link4[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link4[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link4[gbis_tmp + 2];
      Adg0is[1].Link4[g0b_tmp + 6 * i] = g0is[1].Link4[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link4[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link4[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link4[g0b_tmp + 3] = g0is[1].Link4[gbis_tmp];
    Adg0is[1].Link4[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link4[6 * i + 4] = 0.0;
    Adg0is[1].Link4[g0b_tmp + 4] = g0is[1].Link4[gbis_tmp + 1];
    Adg0is[1].Link4[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link4[6 * i + 5] = 0.0;
    Adg0is[1].Link4[g0b_tmp + 5] = g0is[1].Link4[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link4[14];
  dv[6] = gbis[1].Link4[13];
  dv[1] = gbis[1].Link4[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link4[12];
  dv[2] = -gbis[1].Link4[13];
  dv[5] = gbis[1].Link4[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link4[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link4[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link4[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link4[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].Link5[i] = gbis[1].Link5[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link4[gbis_tmp];
    Rbis[1].Link5[3 * i] = gbis[1].Link5[gbis_tmp];
    R0is[1].Link5[3 * i] = g0is[1].Link5[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link4[gbis_tmp + 1];
    Rbis[1].Link5[b_gbis_tmp] = gbis[1].Link5[gbis_tmp + 1];
    R0is[1].Link5[b_gbis_tmp] = g0is[1].Link5[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link4[gbis_tmp + 2];
    Rbis[1].Link5[b_gbis_tmp] = gbis[1].Link5[gbis_tmp + 2];
    R0is[1].Link5[b_gbis_tmp] = g0is[1].Link5[gbis_tmp + 2];
    p0is[1].Link5[i] = g0is[1].Link5[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link4);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link5[14];
  dv[6] = gbis[1].Link5[13];
  dv[1] = gbis[1].Link5[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link5[12];
  dv[2] = -gbis[1].Link5[13];
  dv[5] = gbis[1].Link5[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link5[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link5[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link5[gbis_tmp + 2];
      Adgbis[1].Link5[g0b_tmp + 6 * i] = gbis[1].Link5[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].Link5[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].Link5[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].Link5[g0b_tmp + 3] = gbis[1].Link5[gbis_tmp];
    Adgbis[1].Link5[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].Link5[6 * i + 4] = 0.0;
    Adgbis[1].Link5[g0b_tmp + 4] = gbis[1].Link5[gbis_tmp + 1];
    Adgbis[1].Link5[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].Link5[6 * i + 5] = 0.0;
    Adgbis[1].Link5[g0b_tmp + 5] = gbis[1].Link5[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].Link5[14];
  dv[6] = g0is[1].Link5[13];
  dv[1] = g0is[1].Link5[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].Link5[12];
  dv[2] = -g0is[1].Link5[13];
  dv[5] = g0is[1].Link5[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].Link5[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].Link5[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].Link5[gbis_tmp + 2];
      Adg0is[1].Link5[g0b_tmp + 6 * i] = g0is[1].Link5[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].Link5[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].Link5[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].Link5[g0b_tmp + 3] = g0is[1].Link5[gbis_tmp];
    Adg0is[1].Link5[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].Link5[6 * i + 4] = 0.0;
    Adg0is[1].Link5[g0b_tmp + 4] = g0is[1].Link5[gbis_tmp + 1];
    Adg0is[1].Link5[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].Link5[6 * i + 5] = 0.0;
    Adg0is[1].Link5[g0b_tmp + 5] = g0is[1].Link5[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].Link5[14];
  dv[6] = gbis[1].Link5[13];
  dv[1] = gbis[1].Link5[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].Link5[12];
  dv[2] = -gbis[1].Link5[13];
  dv[5] = gbis[1].Link5[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].Link5[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].Link5[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].Link5[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].Link5[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    pbis[1].EE[i] = gbis[1].EE[i + 12];
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].Link5[gbis_tmp];
    Rbis[1].EE[3 * i] = gbis[1].EE[gbis_tmp];
    R0is[1].EE[3 * i] = g0is[1].EE[gbis_tmp];
    b_gbis_tmp = 3 * i + 1;
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].Link5[gbis_tmp + 1];
    Rbis[1].EE[b_gbis_tmp] = gbis[1].EE[gbis_tmp + 1];
    R0is[1].EE[b_gbis_tmp] = g0is[1].EE[gbis_tmp + 1];
    b_gbis_tmp = 3 * i + 2;
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[b_gbis_tmp];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].Link5[gbis_tmp + 2];
    Rbis[1].EE[b_gbis_tmp] = gbis[1].EE[gbis_tmp + 2];
    R0is[1].EE[b_gbis_tmp] = g0is[1].EE[gbis_tmp + 2];
    p0is[1].EE[i] = g0is[1].EE[i + 12];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].Link5);
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].EE[14];
  dv[6] = gbis[1].EE[13];
  dv[1] = gbis[1].EE[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].EE[12];
  dv[2] = -gbis[1].EE[13];
  dv[5] = gbis[1].EE[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].EE[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].EE[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].EE[gbis_tmp + 2];
      Adgbis[1].EE[g0b_tmp + 6 * i] = gbis[1].EE[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adgbis[1].EE[g0b_tmp] = c_Ry_tmp[3 * i];
    Adgbis[1].EE[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adgbis[1].EE[g0b_tmp + 3] = gbis[1].EE[gbis_tmp];
    Adgbis[1].EE[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adgbis[1].EE[6 * i + 4] = 0.0;
    Adgbis[1].EE[g0b_tmp + 4] = gbis[1].EE[gbis_tmp + 1];
    Adgbis[1].EE[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adgbis[1].EE[6 * i + 5] = 0.0;
    Adgbis[1].EE[g0b_tmp + 5] = gbis[1].EE[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -g0is[1].EE[14];
  dv[6] = g0is[1].EE[13];
  dv[1] = g0is[1].EE[14];
  dv[4] = 0.0;
  dv[7] = -g0is[1].EE[12];
  dv[2] = -g0is[1].EE[13];
  dv[5] = g0is[1].EE[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * g0is[1].EE[gbis_tmp] +
                                   b_Rz_tmp * g0is[1].EE[gbis_tmp + 1]) +
                                  Ry_tmp * g0is[1].EE[gbis_tmp + 2];
      Adg0is[1].EE[g0b_tmp + 6 * i] = g0is[1].EE[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    Adg0is[1].EE[g0b_tmp] = c_Ry_tmp[3 * i];
    Adg0is[1].EE[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    Adg0is[1].EE[g0b_tmp + 3] = g0is[1].EE[gbis_tmp];
    Adg0is[1].EE[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    Adg0is[1].EE[6 * i + 4] = 0.0;
    Adg0is[1].EE[g0b_tmp + 4] = g0is[1].EE[gbis_tmp + 1];
    Adg0is[1].EE[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    Adg0is[1].EE[6 * i + 5] = 0.0;
    Adg0is[1].EE[g0b_tmp + 5] = g0is[1].EE[gbis_tmp + 2];
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -gbis[1].EE[14];
  dv[6] = gbis[1].EE[13];
  dv[1] = gbis[1].EE[14];
  dv[4] = 0.0;
  dv[7] = -gbis[1].EE[12];
  dv[2] = -gbis[1].EE[13];
  dv[5] = gbis[1].EE[12];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    Rz_tmp = dv[i];
    b_Rz_tmp = dv[i + 3];
    Ry_tmp = dv[i + 6];
    for (g0b_tmp = 0; g0b_tmp < 3; g0b_tmp++) {
      gbis_tmp = g0b_tmp << 2;
      c_Ry_tmp[i + 3 * g0b_tmp] = (Rz_tmp * gbis[1].EE[gbis_tmp] +
                                   b_Rz_tmp * gbis[1].EE[gbis_tmp + 1]) +
                                  Ry_tmp * gbis[1].EE[gbis_tmp + 2];
      b_gbis[g0b_tmp + 6 * i] = gbis[1].EE[g0b_tmp + (i << 2)];
    }
  }
  for (int i{0}; i < 3; i++) {
    g0b_tmp = 6 * (i + 3);
    b_gbis[g0b_tmp] = c_Ry_tmp[3 * i];
    b_gbis[6 * i + 3] = 0.0;
    gbis_tmp = i << 2;
    b_gbis[g0b_tmp + 3] = gbis[1].EE[gbis_tmp];
    b_gbis[g0b_tmp + 1] = c_Ry_tmp[3 * i + 1];
    b_gbis[6 * i + 4] = 0.0;
    b_gbis[g0b_tmp + 4] = gbis[1].EE[gbis_tmp + 1];
    b_gbis[g0b_tmp + 2] = c_Ry_tmp[3 * i + 2];
    b_gbis[6 * i + 5] = 0.0;
    b_gbis[g0b_tmp + 5] = gbis[1].EE[gbis_tmp + 2];
  }
  coder::mpower(b_gbis, Adgbi_invs[1].EE);
  for (g0b_tmp = 0; g0b_tmp < 2; g0b_tmp++) {
    std::copy(&g0b[0], &g0b[16], &transforms[g0b_tmp].g0b[0]);
    transforms[g0b_tmp].Rbi = Rbis[g0b_tmp];
    transforms[g0b_tmp].pbi = pbis[g0b_tmp];
    transforms[g0b_tmp].R0i = R0is[g0b_tmp];
    transforms[g0b_tmp].p0i = p0is[g0b_tmp];
    transforms[g0b_tmp].gbi = gbis[g0b_tmp];
    transforms[g0b_tmp].g0i = g0is[g0b_tmp];
    transforms[g0b_tmp].Adgbi = Adgbis[g0b_tmp];
    transforms[g0b_tmp].Adg0i = Adg0is[g0b_tmp];
    transforms[g0b_tmp].Adgbi_inv = Adgbi_invs[g0b_tmp];
  }
}

//
// File trailer for calculateTransforms.cpp
//
// [EOF]
//
