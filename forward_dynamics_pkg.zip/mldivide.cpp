//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: mldivide.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "mldivide.h"
#include "coder_array.h"
#include <algorithm>
#include <cmath>

// Function Definitions
//
// Arguments    : const double A[196]
//                const ::coder::array<double, 1U> &B
//                double Y_data[]
// Return Type  : int
//
namespace coder {
int mldivide(const double A[196], const ::coder::array<double, 1U> &B,
             double Y_data[])
{
  double b_A[196];
  double smax;
  int Y_size;
  int a;
  int i;
  int jA;
  signed char ipiv[14];
  Y_size = B.size(0);
  jA = B.size(0);
  for (i = 0; i < jA; i++) {
    Y_data[i] = B[i];
  }
  std::copy(&A[0], &A[196], &b_A[0]);
  for (i = 0; i < 14; i++) {
    ipiv[i] = static_cast<signed char>(i + 1);
  }
  for (int j{0}; j < 13; j++) {
    int A_tmp;
    int b_tmp;
    int jp1j;
    int mmj_tmp;
    signed char i1;
    mmj_tmp = 12 - j;
    b_tmp = j * 15;
    jp1j = b_tmp + 2;
    jA = 14 - j;
    a = 0;
    smax = std::abs(b_A[b_tmp]);
    for (int k{2}; k <= jA; k++) {
      double s;
      s = std::abs(b_A[(b_tmp + k) - 1]);
      if (s > smax) {
        a = k - 1;
        smax = s;
      }
    }
    if (b_A[b_tmp + a] != 0.0) {
      if (a != 0) {
        jA = j + a;
        ipiv[j] = static_cast<signed char>(jA + 1);
        for (int k{0}; k < 14; k++) {
          a = j + k * 14;
          smax = b_A[a];
          A_tmp = jA + k * 14;
          b_A[a] = b_A[A_tmp];
          b_A[A_tmp] = smax;
        }
      }
      i = (b_tmp - j) + 14;
      for (a = jp1j; a <= i; a++) {
        b_A[a - 1] /= b_A[b_tmp];
      }
    }
    jA = b_tmp;
    for (A_tmp = 0; A_tmp <= mmj_tmp; A_tmp++) {
      smax = b_A[(b_tmp + A_tmp * 14) + 14];
      if (smax != 0.0) {
        i = jA + 16;
        a = (jA - j) + 28;
        for (jp1j = i; jp1j <= a; jp1j++) {
          b_A[jp1j - 1] += b_A[((b_tmp + jp1j) - jA) - 15] * -smax;
        }
      }
      jA += 14;
    }
    i1 = ipiv[j];
    if (i1 != j + 1) {
      smax = Y_data[j];
      Y_data[j] = Y_data[i1 - 1];
      Y_data[i1 - 1] = smax;
    }
  }
  for (int k{0}; k < 14; k++) {
    jA = 14 * k;
    if (Y_data[k] != 0.0) {
      i = k + 2;
      for (a = i; a < 15; a++) {
        Y_data[a - 1] -= Y_data[k] * b_A[(a + jA) - 1];
      }
    }
  }
  for (int k{13}; k >= 0; k--) {
    jA = 14 * k;
    smax = Y_data[k];
    if (smax != 0.0) {
      smax /= b_A[k + jA];
      Y_data[k] = smax;
      for (a = 0; a < k; a++) {
        Y_data[a] -= Y_data[k] * b_A[a + jA];
      }
    }
  }
  return Y_size;
}

} // namespace coder

//
// File trailer for mldivide.cpp
//
// [EOF]
//
