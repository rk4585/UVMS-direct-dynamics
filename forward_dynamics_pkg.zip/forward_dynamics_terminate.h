//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics_terminate.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef FORWARD_DYNAMICS_TERMINATE_H
#define FORWARD_DYNAMICS_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void forward_dynamics_terminate();

#endif
//
// File trailer for forward_dynamics_terminate.h
//
// [EOF]
//
