//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics_types.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef FORWARD_DYNAMICS_TYPES_H
#define FORWARD_DYNAMICS_TYPES_H

// Include Files
#include "rtwtypes.h"

// Type Definitions
struct struct3_T {
  double d[5];
  double theta[5];
  double a[5];
  double alpha[5];
};

struct struct5_T {
  double Mass;
  double CenterOfMass[3];
  double InertiaTensor[9];
  double Volume;
  double CenterOfBuoyancy[3];
  double AddedMass[36];
  double LinearDamping[36];
  double QuadraticDamping[36];
};

struct struct4_T {
  struct5_T Link1;
  struct5_T Link2;
  struct5_T Link3;
  struct5_T Link4;
  struct5_T Link5;
};

struct struct7_T {
  double TransformParentToChild[16];
};

struct struct6_T {
  struct7_T Joint1;
  struct7_T Joint2;
  struct7_T Joint3;
  struct7_T Joint4;
};

struct struct2_T {
  double TransformVehicleToArmBase[16];
  double LastLinkToEE[16];
  struct3_T DHParameters;
  double JointVariables[4];
  double JointVelocities[4];
  double NumDofs;
  double ZeroPosition[4];
  struct4_T Links;
  struct6_T Joints;
};

struct struct1_T {
  struct2_T Arm1;
  struct2_T Arm2;
};

struct struct0_T {
  double Pose[6];
  double QuasiVel[6];
  double Mass;
  double CenterOfMass[3];
  double Inertia[9];
  double NumThrusters;
  double ThrusterAllocationMatrix[42];
  double Volume;
  double CenterOfBuoyancy[3];
  double AddedMassMatrix[36];
  double LinearDamping[36];
  double QuadraticDamping[36];
  double NumDoFs;
  double g;
  double rho;
  struct1_T Arms;
};

#endif
//
// File trailer for forward_dynamics_types.h
//
// [EOF]
//
