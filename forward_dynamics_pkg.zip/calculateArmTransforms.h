//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateArmTransforms.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef CALCULATEARMTRANSFORMS_H
#define CALCULATEARMTRANSFORMS_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void b_calculateArmTransforms(
    const double params_Arms_Arm2_TransformVehicleToArmBase[16],
    const double params_Arms_Arm2_LastLinkToEE[16],
    const double params_Arms_Arm2_DHParameters_d[5],
    const double params_Arms_Arm2_DHParameters_theta[5],
    const double params_Arms_Arm2_DHParameters_a[5],
    const double params_Arms_Arm2_DHParameters_alpha[5], const double ksi[14],
    const double T_global[16], double arm_transforms_Link1[16],
    double arm_transforms_Link2[16], double arm_transforms_Link3[16],
    double arm_transforms_Link4[16], double arm_transforms_Link5[16],
    double arm_transforms_EE[16]);

void calculateArmTransforms(
    const double params_Arms_Arm1_TransformVehicleToArmBase[16],
    const double params_Arms_Arm1_LastLinkToEE[16],
    const double params_Arms_Arm1_DHParameters_d[5],
    const double params_Arms_Arm1_DHParameters_theta[5],
    const double params_Arms_Arm1_DHParameters_a[5],
    const double params_Arms_Arm1_DHParameters_alpha[5], const double ksi[14],
    const double T_global[16], double arm_transforms_Link1[16],
    double arm_transforms_Link2[16], double arm_transforms_Link3[16],
    double arm_transforms_Link4[16], double arm_transforms_Link5[16],
    double arm_transforms_EE[16]);

#endif
//
// File trailer for calculateArmTransforms.h
//
// [EOF]
//
