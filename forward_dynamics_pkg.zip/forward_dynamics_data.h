//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics_data.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef FORWARD_DYNAMICS_DATA_H
#define FORWARD_DYNAMICS_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern const signed char iv[18];
extern const signed char iv1[9];

#endif
//
// File trailer for forward_dynamics_data.h
//
// [EOF]
//
