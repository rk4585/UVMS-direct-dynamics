//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics_data.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "forward_dynamics_data.h"

// Variable Definitions
const signed char iv[18]{0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1};

const signed char iv1[9]{1, 0, 0, 0, 1, 0, 0, 0, 1};

//
// File trailer for forward_dynamics_data.cpp
//
// [EOF]
//
