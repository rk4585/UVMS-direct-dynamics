//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateJacobiansTimeDerivative.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "calculateJacobiansTimeDerivative.h"
#include "forward_dynamics_data.h"
#include "forward_dynamics_internal_types.h"
#include <algorithm>
#include <cstring>

// Type Definitions
struct i_struct_T {
  g_struct_T dAdgbi_dt;
  g_struct_T dAdgbi_inv_dt;
};

// Function Definitions
//
// Arguments    : const double zeta[14]
//                const d_struct_T Kinematics_Jacobians[2]
//                const h_struct_T Kinematics_Transforms[2]
//                b_struct_T dJbi_dts[2]
// Return Type  : void
//
void calculateJacobiansTimeDerivative(const double zeta[14],
                                      const d_struct_T Kinematics_Jacobians[2],
                                      const h_struct_T Kinematics_Transforms[2],
                                      b_struct_T dJbi_dts[2])
{
  static const signed char b[18]{1, 0, 0, 0, 1, 0, 0, 0, 1,
                                 0, 0, 0, 0, 0, 0, 0, 0, 0};
  static const signed char b_b[6]{0, 0, 0, 0, 0, 1};
  e_struct_T dRbi_dts[2];
  g_struct_T dAdgbi_dts[2];
  g_struct_T dAdgbi_inv_dts[2];
  i_struct_T transforms_dt[2];
  struct_T dpbi_dts[2];
  double c_Kinematics_Transforms[30];
  double b_transforms_dt[24];
  double dJi_dt_EE[24];
  double dJi_dt_Link2[24];
  double dJi_dt_Link3[24];
  double dJi_dt_Link4[24];
  double dJi_dt_Link5[24];
  double d_Kinematics_Transforms[24];
  double b_Kinematics_Transforms[18];
  double b_zeta[10];
  double dv[9];
  double dv1[9];
  double dv2[9];
  double dv3[6];
  double dv4[6];
  double dv5[6];
  double omegabi_Link1[3];
  double d;
  double d1;
  double d2;
  double d3;
  int Kinematics_Transforms_tmp;
  int i1;
  int i2;
  int i3;
  for (int i{0}; i < 3; i++) {
    d = Kinematics_Transforms[0].Rbi.Link1[i];
    d1 = Kinematics_Transforms[0].Rbi.Link1[i + 3];
    d2 = Kinematics_Transforms[0].Rbi.Link1[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link1[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[0]
                  .Jb.Link1[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link1[i] += d3 * zeta[i1 + 6];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Jb.Link1[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  std::copy(&zeta[0], &zeta[10], &b_zeta[0]);
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link1[i + 3 * i1] =
          (d * Kinematics_Transforms[0].Rbi.Link1[3 * i1] +
           d1 * Kinematics_Transforms[0].Rbi.Link1[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[0].Rbi.Link1[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[0].pbi.Link1[2];
  dv[6] = Kinematics_Transforms[0].pbi.Link1[1];
  dv[1] = Kinematics_Transforms[0].pbi.Link1[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[0].pbi.Link1[0];
  dv[2] = -Kinematics_Transforms[0].pbi.Link1[1];
  dv[5] = Kinematics_Transforms[0].pbi.Link1[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link1[2];
  dv1[6] = dpbi_dts[1].Link1[1];
  dv1[1] = dpbi_dts[1].Link1[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link1[0];
  dv1[2] = -dpbi_dts[1].Link1[1];
  dv1[5] = dpbi_dts[1].Link1[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link1[3 * i1] + d1 * dRbi_dts[1].Link1[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link1[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[0].Rbi.Link1[3 * i1] +
                        d1 * Kinematics_Transforms[0].Rbi.Link1[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[0].Rbi.Link1[3 * i1 + 2];
      dAdgbi_dts[1].Link1[i1 + 6 * i] = dRbi_dts[1].Link1[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link1[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link1[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link1[i1 + 3] = dRbi_dts[1].Link1[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link1[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link1[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link1[i1 + 4] = dRbi_dts[1].Link1[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link1[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link1[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link1[i1 + 5] = dRbi_dts[1].Link1[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[0].Rbi.Link2[i];
    d1 = Kinematics_Transforms[0].Rbi.Link2[i + 3];
    d2 = Kinematics_Transforms[0].Rbi.Link2[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link2[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[0]
                  .Jb.Link2[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link2[i] += d3 * zeta[i1 + 6];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Jb.Link2[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  std::copy(&zeta[0], &zeta[10], &b_zeta[0]);
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link2[i + 3 * i1] =
          (d * Kinematics_Transforms[0].Rbi.Link2[3 * i1] +
           d1 * Kinematics_Transforms[0].Rbi.Link2[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[0].Rbi.Link2[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[0].pbi.Link2[2];
  dv[6] = Kinematics_Transforms[0].pbi.Link2[1];
  dv[1] = Kinematics_Transforms[0].pbi.Link2[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[0].pbi.Link2[0];
  dv[2] = -Kinematics_Transforms[0].pbi.Link2[1];
  dv[5] = Kinematics_Transforms[0].pbi.Link2[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link2[2];
  dv1[6] = dpbi_dts[1].Link2[1];
  dv1[1] = dpbi_dts[1].Link2[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link2[0];
  dv1[2] = -dpbi_dts[1].Link2[1];
  dv1[5] = dpbi_dts[1].Link2[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link2[3 * i1] + d1 * dRbi_dts[1].Link2[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link2[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[0].Rbi.Link2[3 * i1] +
                        d1 * Kinematics_Transforms[0].Rbi.Link2[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[0].Rbi.Link2[3 * i1 + 2];
      dAdgbi_dts[1].Link2[i1 + 6 * i] = dRbi_dts[1].Link2[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link2[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link2[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link2[i1 + 3] = dRbi_dts[1].Link2[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link2[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link2[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link2[i1 + 4] = dRbi_dts[1].Link2[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link2[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link2[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link2[i1 + 5] = dRbi_dts[1].Link2[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[0].Rbi.Link3[i];
    d1 = Kinematics_Transforms[0].Rbi.Link3[i + 3];
    d2 = Kinematics_Transforms[0].Rbi.Link3[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link3[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[0]
                  .Jb.Link3[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link3[i] += d3 * zeta[i1 + 6];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Jb.Link3[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  std::copy(&zeta[0], &zeta[10], &b_zeta[0]);
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link3[i + 3 * i1] =
          (d * Kinematics_Transforms[0].Rbi.Link3[3 * i1] +
           d1 * Kinematics_Transforms[0].Rbi.Link3[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[0].Rbi.Link3[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[0].pbi.Link3[2];
  dv[6] = Kinematics_Transforms[0].pbi.Link3[1];
  dv[1] = Kinematics_Transforms[0].pbi.Link3[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[0].pbi.Link3[0];
  dv[2] = -Kinematics_Transforms[0].pbi.Link3[1];
  dv[5] = Kinematics_Transforms[0].pbi.Link3[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link3[2];
  dv1[6] = dpbi_dts[1].Link3[1];
  dv1[1] = dpbi_dts[1].Link3[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link3[0];
  dv1[2] = -dpbi_dts[1].Link3[1];
  dv1[5] = dpbi_dts[1].Link3[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link3[3 * i1] + d1 * dRbi_dts[1].Link3[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link3[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[0].Rbi.Link3[3 * i1] +
                        d1 * Kinematics_Transforms[0].Rbi.Link3[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[0].Rbi.Link3[3 * i1 + 2];
      dAdgbi_dts[1].Link3[i1 + 6 * i] = dRbi_dts[1].Link3[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link3[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link3[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link3[i1 + 3] = dRbi_dts[1].Link3[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link3[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link3[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link3[i1 + 4] = dRbi_dts[1].Link3[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link3[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link3[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link3[i1 + 5] = dRbi_dts[1].Link3[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[0].Rbi.Link4[i];
    d1 = Kinematics_Transforms[0].Rbi.Link4[i + 3];
    d2 = Kinematics_Transforms[0].Rbi.Link4[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link4[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[0]
                  .Jb.Link4[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link4[i] += d3 * zeta[i1 + 6];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Jb.Link4[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  std::copy(&zeta[0], &zeta[10], &b_zeta[0]);
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link4[i + 3 * i1] =
          (d * Kinematics_Transforms[0].Rbi.Link4[3 * i1] +
           d1 * Kinematics_Transforms[0].Rbi.Link4[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[0].Rbi.Link4[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[0].pbi.Link4[2];
  dv[6] = Kinematics_Transforms[0].pbi.Link4[1];
  dv[1] = Kinematics_Transforms[0].pbi.Link4[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[0].pbi.Link4[0];
  dv[2] = -Kinematics_Transforms[0].pbi.Link4[1];
  dv[5] = Kinematics_Transforms[0].pbi.Link4[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link4[2];
  dv1[6] = dpbi_dts[1].Link4[1];
  dv1[1] = dpbi_dts[1].Link4[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link4[0];
  dv1[2] = -dpbi_dts[1].Link4[1];
  dv1[5] = dpbi_dts[1].Link4[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link4[3 * i1] + d1 * dRbi_dts[1].Link4[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link4[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[0].Rbi.Link4[3 * i1] +
                        d1 * Kinematics_Transforms[0].Rbi.Link4[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[0].Rbi.Link4[3 * i1 + 2];
      dAdgbi_dts[1].Link4[i1 + 6 * i] = dRbi_dts[1].Link4[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link4[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link4[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link4[i1 + 3] = dRbi_dts[1].Link4[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link4[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link4[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link4[i1 + 4] = dRbi_dts[1].Link4[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link4[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link4[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link4[i1 + 5] = dRbi_dts[1].Link4[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[0].Rbi.Link5[i];
    d1 = Kinematics_Transforms[0].Rbi.Link5[i + 3];
    d2 = Kinematics_Transforms[0].Rbi.Link5[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link5[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[0]
                  .Jb.Link5[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link5[i] += d3 * zeta[i1 + 6];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Jb.Link5[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  std::copy(&zeta[0], &zeta[10], &b_zeta[0]);
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link5[i + 3 * i1] =
          (d * Kinematics_Transforms[0].Rbi.Link5[3 * i1] +
           d1 * Kinematics_Transforms[0].Rbi.Link5[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[0].Rbi.Link5[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[0].pbi.Link5[2];
  dv[6] = Kinematics_Transforms[0].pbi.Link5[1];
  dv[1] = Kinematics_Transforms[0].pbi.Link5[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[0].pbi.Link5[0];
  dv[2] = -Kinematics_Transforms[0].pbi.Link5[1];
  dv[5] = Kinematics_Transforms[0].pbi.Link5[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link5[2];
  dv1[6] = dpbi_dts[1].Link5[1];
  dv1[1] = dpbi_dts[1].Link5[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link5[0];
  dv1[2] = -dpbi_dts[1].Link5[1];
  dv1[5] = dpbi_dts[1].Link5[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link5[3 * i1] + d1 * dRbi_dts[1].Link5[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link5[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[0].Rbi.Link5[3 * i1] +
                        d1 * Kinematics_Transforms[0].Rbi.Link5[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[0].Rbi.Link5[3 * i1 + 2];
      dAdgbi_dts[1].Link5[i1 + 6 * i] = dRbi_dts[1].Link5[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link5[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link5[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link5[i1 + 3] = dRbi_dts[1].Link5[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link5[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link5[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link5[i1 + 4] = dRbi_dts[1].Link5[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link5[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link5[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link5[i1 + 5] = dRbi_dts[1].Link5[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[0].Rbi.EE[i];
    d1 = Kinematics_Transforms[0].Rbi.EE[i + 3];
    d2 = Kinematics_Transforms[0].Rbi.EE[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].EE[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[0]
                  .Jb.EE[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].EE[i] += d3 * zeta[i1 + 6];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0].Jb.EE[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  std::copy(&zeta[0], &zeta[10], &b_zeta[0]);
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].EE[i + 3 * i1] =
          (d * Kinematics_Transforms[0].Rbi.EE[3 * i1] +
           d1 * Kinematics_Transforms[0].Rbi.EE[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[0].Rbi.EE[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[0].pbi.EE[2];
  dv[6] = Kinematics_Transforms[0].pbi.EE[1];
  dv[1] = Kinematics_Transforms[0].pbi.EE[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[0].pbi.EE[0];
  dv[2] = -Kinematics_Transforms[0].pbi.EE[1];
  dv[5] = Kinematics_Transforms[0].pbi.EE[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].EE[2];
  dv1[6] = dpbi_dts[1].EE[1];
  dv1[1] = dpbi_dts[1].EE[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].EE[0];
  dv1[2] = -dpbi_dts[1].EE[1];
  dv1[5] = dpbi_dts[1].EE[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].EE[3 * i1] + d1 * dRbi_dts[1].EE[3 * i1 + 1]) +
          d2 * dRbi_dts[1].EE[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[0].Rbi.EE[3 * i1] +
                        d1 * Kinematics_Transforms[0].Rbi.EE[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[0].Rbi.EE[3 * i1 + 2];
      dAdgbi_dts[1].EE[i1 + 6 * i] = dRbi_dts[1].EE[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].EE[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].EE[6 * i + 3] = 0.0;
    dAdgbi_dts[1].EE[i1 + 3] = dRbi_dts[1].EE[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].EE[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].EE[6 * i + 4] = 0.0;
    dAdgbi_dts[1].EE[i1 + 4] = dRbi_dts[1].EE[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].EE[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].EE[6 * i + 5] = 0.0;
    dAdgbi_dts[1].EE[i1 + 5] = dRbi_dts[1].EE[Kinematics_Transforms_tmp];
  }
  for (int i{0}; i < 36; i++) {
    double d4;
    double d5;
    d = dAdgbi_dts[1].Link1[i];
    dAdgbi_dts[0].Link1[i] = d;
    d1 = dAdgbi_dts[1].Link2[i];
    dAdgbi_dts[0].Link2[i] = d1;
    d2 = dAdgbi_dts[1].Link3[i];
    dAdgbi_dts[0].Link3[i] = d2;
    d3 = dAdgbi_dts[1].Link4[i];
    dAdgbi_dts[0].Link4[i] = d3;
    d4 = dAdgbi_dts[1].Link5[i];
    dAdgbi_dts[0].Link5[i] = d4;
    d5 = dAdgbi_dts[1].EE[i];
    dAdgbi_dts[0].EE[i] = d5;
    dAdgbi_inv_dts[0].Link1[i] = d;
    dAdgbi_inv_dts[0].Link2[i] = d1;
    dAdgbi_inv_dts[0].Link3[i] = d2;
    dAdgbi_inv_dts[0].Link4[i] = d3;
    dAdgbi_inv_dts[0].Link5[i] = d4;
    dAdgbi_inv_dts[0].EE[i] = d5;
  }
  for (int i{0}; i < 3; i++) {
    d = Kinematics_Transforms[1].Rbi.Link1[i];
    d1 = Kinematics_Transforms[1].Rbi.Link1[i + 3];
    d2 = Kinematics_Transforms[1].Rbi.Link1[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link1[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[1]
                  .Jb.Link1[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link1[i] += d3 * zeta[i1 + 10];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Jb.Link1[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    b_zeta[i] = zeta[i];
  }
  b_zeta[6] = zeta[10];
  b_zeta[7] = zeta[11];
  b_zeta[8] = zeta[12];
  b_zeta[9] = zeta[13];
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link1[i + 3 * i1] =
          (d * Kinematics_Transforms[1].Rbi.Link1[3 * i1] +
           d1 * Kinematics_Transforms[1].Rbi.Link1[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[1].Rbi.Link1[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[1].pbi.Link1[2];
  dv[6] = Kinematics_Transforms[1].pbi.Link1[1];
  dv[1] = Kinematics_Transforms[1].pbi.Link1[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[1].pbi.Link1[0];
  dv[2] = -Kinematics_Transforms[1].pbi.Link1[1];
  dv[5] = Kinematics_Transforms[1].pbi.Link1[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link1[2];
  dv1[6] = dpbi_dts[1].Link1[1];
  dv1[1] = dpbi_dts[1].Link1[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link1[0];
  dv1[2] = -dpbi_dts[1].Link1[1];
  dv1[5] = dpbi_dts[1].Link1[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link1[3 * i1] + d1 * dRbi_dts[1].Link1[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link1[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[1].Rbi.Link1[3 * i1] +
                        d1 * Kinematics_Transforms[1].Rbi.Link1[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[1].Rbi.Link1[3 * i1 + 2];
      dAdgbi_dts[1].Link1[i1 + 6 * i] = dRbi_dts[1].Link1[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link1[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link1[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link1[i1 + 3] = dRbi_dts[1].Link1[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link1[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link1[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link1[i1 + 4] = dRbi_dts[1].Link1[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link1[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link1[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link1[i1 + 5] = dRbi_dts[1].Link1[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[1].Rbi.Link2[i];
    d1 = Kinematics_Transforms[1].Rbi.Link2[i + 3];
    d2 = Kinematics_Transforms[1].Rbi.Link2[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link2[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[1]
                  .Jb.Link2[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link2[i] += d3 * zeta[i1 + 10];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Jb.Link2[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    b_zeta[i] = zeta[i];
  }
  b_zeta[6] = zeta[10];
  b_zeta[7] = zeta[11];
  b_zeta[8] = zeta[12];
  b_zeta[9] = zeta[13];
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link2[i + 3 * i1] =
          (d * Kinematics_Transforms[1].Rbi.Link2[3 * i1] +
           d1 * Kinematics_Transforms[1].Rbi.Link2[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[1].Rbi.Link2[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[1].pbi.Link2[2];
  dv[6] = Kinematics_Transforms[1].pbi.Link2[1];
  dv[1] = Kinematics_Transforms[1].pbi.Link2[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[1].pbi.Link2[0];
  dv[2] = -Kinematics_Transforms[1].pbi.Link2[1];
  dv[5] = Kinematics_Transforms[1].pbi.Link2[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link2[2];
  dv1[6] = dpbi_dts[1].Link2[1];
  dv1[1] = dpbi_dts[1].Link2[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link2[0];
  dv1[2] = -dpbi_dts[1].Link2[1];
  dv1[5] = dpbi_dts[1].Link2[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link2[3 * i1] + d1 * dRbi_dts[1].Link2[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link2[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[1].Rbi.Link2[3 * i1] +
                        d1 * Kinematics_Transforms[1].Rbi.Link2[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[1].Rbi.Link2[3 * i1 + 2];
      dAdgbi_dts[1].Link2[i1 + 6 * i] = dRbi_dts[1].Link2[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link2[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link2[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link2[i1 + 3] = dRbi_dts[1].Link2[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link2[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link2[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link2[i1 + 4] = dRbi_dts[1].Link2[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link2[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link2[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link2[i1 + 5] = dRbi_dts[1].Link2[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[1].Rbi.Link3[i];
    d1 = Kinematics_Transforms[1].Rbi.Link3[i + 3];
    d2 = Kinematics_Transforms[1].Rbi.Link3[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link3[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[1]
                  .Jb.Link3[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link3[i] += d3 * zeta[i1 + 10];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Jb.Link3[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    b_zeta[i] = zeta[i];
  }
  b_zeta[6] = zeta[10];
  b_zeta[7] = zeta[11];
  b_zeta[8] = zeta[12];
  b_zeta[9] = zeta[13];
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link3[i + 3 * i1] =
          (d * Kinematics_Transforms[1].Rbi.Link3[3 * i1] +
           d1 * Kinematics_Transforms[1].Rbi.Link3[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[1].Rbi.Link3[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[1].pbi.Link3[2];
  dv[6] = Kinematics_Transforms[1].pbi.Link3[1];
  dv[1] = Kinematics_Transforms[1].pbi.Link3[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[1].pbi.Link3[0];
  dv[2] = -Kinematics_Transforms[1].pbi.Link3[1];
  dv[5] = Kinematics_Transforms[1].pbi.Link3[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link3[2];
  dv1[6] = dpbi_dts[1].Link3[1];
  dv1[1] = dpbi_dts[1].Link3[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link3[0];
  dv1[2] = -dpbi_dts[1].Link3[1];
  dv1[5] = dpbi_dts[1].Link3[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link3[3 * i1] + d1 * dRbi_dts[1].Link3[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link3[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[1].Rbi.Link3[3 * i1] +
                        d1 * Kinematics_Transforms[1].Rbi.Link3[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[1].Rbi.Link3[3 * i1 + 2];
      dAdgbi_dts[1].Link3[i1 + 6 * i] = dRbi_dts[1].Link3[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link3[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link3[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link3[i1 + 3] = dRbi_dts[1].Link3[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link3[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link3[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link3[i1 + 4] = dRbi_dts[1].Link3[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link3[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link3[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link3[i1 + 5] = dRbi_dts[1].Link3[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[1].Rbi.Link4[i];
    d1 = Kinematics_Transforms[1].Rbi.Link4[i + 3];
    d2 = Kinematics_Transforms[1].Rbi.Link4[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link4[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[1]
                  .Jb.Link4[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link4[i] += d3 * zeta[i1 + 10];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Jb.Link4[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    b_zeta[i] = zeta[i];
  }
  b_zeta[6] = zeta[10];
  b_zeta[7] = zeta[11];
  b_zeta[8] = zeta[12];
  b_zeta[9] = zeta[13];
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link4[i + 3 * i1] =
          (d * Kinematics_Transforms[1].Rbi.Link4[3 * i1] +
           d1 * Kinematics_Transforms[1].Rbi.Link4[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[1].Rbi.Link4[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[1].pbi.Link4[2];
  dv[6] = Kinematics_Transforms[1].pbi.Link4[1];
  dv[1] = Kinematics_Transforms[1].pbi.Link4[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[1].pbi.Link4[0];
  dv[2] = -Kinematics_Transforms[1].pbi.Link4[1];
  dv[5] = Kinematics_Transforms[1].pbi.Link4[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link4[2];
  dv1[6] = dpbi_dts[1].Link4[1];
  dv1[1] = dpbi_dts[1].Link4[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link4[0];
  dv1[2] = -dpbi_dts[1].Link4[1];
  dv1[5] = dpbi_dts[1].Link4[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link4[3 * i1] + d1 * dRbi_dts[1].Link4[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link4[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[1].Rbi.Link4[3 * i1] +
                        d1 * Kinematics_Transforms[1].Rbi.Link4[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[1].Rbi.Link4[3 * i1 + 2];
      dAdgbi_dts[1].Link4[i1 + 6 * i] = dRbi_dts[1].Link4[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link4[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link4[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link4[i1 + 3] = dRbi_dts[1].Link4[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link4[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link4[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link4[i1 + 4] = dRbi_dts[1].Link4[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link4[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link4[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link4[i1 + 5] = dRbi_dts[1].Link4[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[1].Rbi.Link5[i];
    d1 = Kinematics_Transforms[1].Rbi.Link5[i + 3];
    d2 = Kinematics_Transforms[1].Rbi.Link5[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].Link5[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[1]
                  .Jb.Link5[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].Link5[i] += d3 * zeta[i1 + 10];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Jb.Link5[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    b_zeta[i] = zeta[i];
  }
  b_zeta[6] = zeta[10];
  b_zeta[7] = zeta[11];
  b_zeta[8] = zeta[12];
  b_zeta[9] = zeta[13];
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].Link5[i + 3 * i1] =
          (d * Kinematics_Transforms[1].Rbi.Link5[3 * i1] +
           d1 * Kinematics_Transforms[1].Rbi.Link5[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[1].Rbi.Link5[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[1].pbi.Link5[2];
  dv[6] = Kinematics_Transforms[1].pbi.Link5[1];
  dv[1] = Kinematics_Transforms[1].pbi.Link5[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[1].pbi.Link5[0];
  dv[2] = -Kinematics_Transforms[1].pbi.Link5[1];
  dv[5] = Kinematics_Transforms[1].pbi.Link5[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].Link5[2];
  dv1[6] = dpbi_dts[1].Link5[1];
  dv1[1] = dpbi_dts[1].Link5[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].Link5[0];
  dv1[2] = -dpbi_dts[1].Link5[1];
  dv1[5] = dpbi_dts[1].Link5[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].Link5[3 * i1] + d1 * dRbi_dts[1].Link5[3 * i1 + 1]) +
          d2 * dRbi_dts[1].Link5[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[1].Rbi.Link5[3 * i1] +
                        d1 * Kinematics_Transforms[1].Rbi.Link5[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[1].Rbi.Link5[3 * i1 + 2];
      dAdgbi_dts[1].Link5[i1 + 6 * i] = dRbi_dts[1].Link5[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].Link5[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].Link5[6 * i + 3] = 0.0;
    dAdgbi_dts[1].Link5[i1 + 3] = dRbi_dts[1].Link5[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].Link5[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link5[6 * i + 4] = 0.0;
    dAdgbi_dts[1].Link5[i1 + 4] = dRbi_dts[1].Link5[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].Link5[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].Link5[6 * i + 5] = 0.0;
    dAdgbi_dts[1].Link5[i1 + 5] = dRbi_dts[1].Link5[Kinematics_Transforms_tmp];
    d = Kinematics_Transforms[1].Rbi.EE[i];
    d1 = Kinematics_Transforms[1].Rbi.EE[i + 3];
    d2 = Kinematics_Transforms[1].Rbi.EE[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(b[3 * i1]) +
           d1 * static_cast<double>(b[3 * i1 + 1])) +
          d2 * static_cast<double>(b[3 * i1 + 2]);
    }
    dpbi_dts[1].EE[i] = 0.0;
    for (i1 = 0; i1 < 4; i1++) {
      d3 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d3 += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
              Kinematics_Jacobians[1]
                  .Jb.EE[Kinematics_Transforms_tmp + 6 * (i1 + 6)];
      }
      dpbi_dts[1].EE[i] += d3 * zeta[i1 + 10];
    }
    for (i1 = 0; i1 < 6; i1++) {
      b_Kinematics_Transforms[i + 3 * i1] =
          (d * static_cast<double>(iv[3 * i1]) +
           d1 * static_cast<double>(iv[3 * i1 + 1])) +
          d2 * static_cast<double>(iv[3 * i1 + 2]);
    }
    for (i1 = 0; i1 < 10; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += b_Kinematics_Transforms[i + 3 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1].Jb.EE[Kinematics_Transforms_tmp + 6 * i1];
      }
      c_Kinematics_Transforms[i + 3 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    b_zeta[i] = zeta[i];
  }
  b_zeta[6] = zeta[10];
  b_zeta[7] = zeta[11];
  b_zeta[8] = zeta[12];
  b_zeta[9] = zeta[13];
  for (int i{0}; i < 3; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      d += c_Kinematics_Transforms[i + 3 * i1] * b_zeta[i1];
    }
    omegabi_Link1[i] = zeta[i + 3] - d;
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -omegabi_Link1[2];
  dv[6] = omegabi_Link1[1];
  dv[1] = omegabi_Link1[2];
  dv[4] = 0.0;
  dv[7] = -omegabi_Link1[0];
  dv[2] = -omegabi_Link1[1];
  dv[5] = omegabi_Link1[0];
  dv[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dRbi_dts[1].EE[i + 3 * i1] =
          (d * Kinematics_Transforms[1].Rbi.EE[3 * i1] +
           d1 * Kinematics_Transforms[1].Rbi.EE[3 * i1 + 1]) +
          d2 * Kinematics_Transforms[1].Rbi.EE[3 * i1 + 2];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  dv[0] = 0.0;
  dv[3] = -Kinematics_Transforms[1].pbi.EE[2];
  dv[6] = Kinematics_Transforms[1].pbi.EE[1];
  dv[1] = Kinematics_Transforms[1].pbi.EE[2];
  dv[4] = 0.0;
  dv[7] = -Kinematics_Transforms[1].pbi.EE[0];
  dv[2] = -Kinematics_Transforms[1].pbi.EE[1];
  dv[5] = Kinematics_Transforms[1].pbi.EE[0];
  dv[8] = 0.0;
  dv1[0] = 0.0;
  dv1[3] = -dpbi_dts[1].EE[2];
  dv1[6] = dpbi_dts[1].EE[1];
  dv1[1] = dpbi_dts[1].EE[2];
  dv1[4] = 0.0;
  dv1[7] = -dpbi_dts[1].EE[0];
  dv1[2] = -dpbi_dts[1].EE[1];
  dv1[5] = dpbi_dts[1].EE[0];
  dv1[8] = 0.0;
  for (int i{0}; i < 3; i++) {
    d = dv[i];
    d1 = dv[i + 3];
    d2 = dv[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv2[i + 3 * i1] =
          (d * dRbi_dts[1].EE[3 * i1] + d1 * dRbi_dts[1].EE[3 * i1 + 1]) +
          d2 * dRbi_dts[1].EE[3 * i1 + 2];
    }
    d = dv1[i];
    d1 = dv1[i + 3];
    d2 = dv1[i + 6];
    for (i1 = 0; i1 < 3; i1++) {
      dv[i + 3 * i1] = (d * Kinematics_Transforms[1].Rbi.EE[3 * i1] +
                        d1 * Kinematics_Transforms[1].Rbi.EE[3 * i1 + 1]) +
                       d2 * Kinematics_Transforms[1].Rbi.EE[3 * i1 + 2];
      dAdgbi_dts[1].EE[i1 + 6 * i] = dRbi_dts[1].EE[i1 + 3 * i];
    }
  }
  for (int i{0}; i < 3; i++) {
    i1 = 6 * (i + 3);
    dAdgbi_dts[1].EE[i1] = dv2[3 * i] + dv[3 * i];
    dAdgbi_dts[1].EE[6 * i + 3] = 0.0;
    dAdgbi_dts[1].EE[i1 + 3] = dRbi_dts[1].EE[3 * i];
    Kinematics_Transforms_tmp = 3 * i + 1;
    dAdgbi_dts[1].EE[i1 + 1] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].EE[6 * i + 4] = 0.0;
    dAdgbi_dts[1].EE[i1 + 4] = dRbi_dts[1].EE[Kinematics_Transforms_tmp];
    Kinematics_Transforms_tmp = 3 * i + 2;
    dAdgbi_dts[1].EE[i1 + 2] =
        dv2[Kinematics_Transforms_tmp] + dv[Kinematics_Transforms_tmp];
    dAdgbi_dts[1].EE[6 * i + 5] = 0.0;
    dAdgbi_dts[1].EE[i1 + 5] = dRbi_dts[1].EE[Kinematics_Transforms_tmp];
  }
  std::copy(&dAdgbi_dts[1].Link1[0], &dAdgbi_dts[1].Link1[36],
            &dAdgbi_inv_dts[1].Link1[0]);
  std::copy(&dAdgbi_dts[1].Link2[0], &dAdgbi_dts[1].Link2[36],
            &dAdgbi_inv_dts[1].Link2[0]);
  std::copy(&dAdgbi_dts[1].Link3[0], &dAdgbi_dts[1].Link3[36],
            &dAdgbi_inv_dts[1].Link3[0]);
  std::copy(&dAdgbi_dts[1].Link4[0], &dAdgbi_dts[1].Link4[36],
            &dAdgbi_inv_dts[1].Link4[0]);
  std::copy(&dAdgbi_dts[1].Link5[0], &dAdgbi_dts[1].Link5[36],
            &dAdgbi_inv_dts[1].Link5[0]);
  std::copy(&dAdgbi_dts[1].EE[0], &dAdgbi_dts[1].EE[36],
            &dAdgbi_inv_dts[1].EE[0]);
  transforms_dt[0].dAdgbi_dt = dAdgbi_dts[0];
  transforms_dt[0].dAdgbi_inv_dt = dAdgbi_inv_dts[0];
  transforms_dt[1].dAdgbi_dt = dAdgbi_dts[1];
  transforms_dt[1].dAdgbi_inv_dt = dAdgbi_inv_dts[1];
  std::memset(&dJi_dt_Link2[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_Link3[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_Link4[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_Link5[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_EE[0], 0, 24U * sizeof(double));
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      d1 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        i2 = i + 6 * Kinematics_Transforms_tmp;
        d += transforms_dt[0].dAdgbi_inv_dt.Link1[i2] *
             Kinematics_Jacobians[0]
                 .Ji.Link1[Kinematics_Transforms_tmp + 6 * i1];
        d1 += Kinematics_Transforms[0].Adgbi_inv.Link1[i2] * 0.0;
      }
      Kinematics_Transforms_tmp = i + 6 * i1;
      d_Kinematics_Transforms[Kinematics_Transforms_tmp] = d1;
      b_transforms_dt[Kinematics_Transforms_tmp] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link1[Kinematics_Transforms_tmp] =
          transforms_dt[0].dAdgbi_inv_dt.Link1[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link1[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[0].dAdgbi_dt.Link1[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dv3[i] = d;
    dJi_dt_Link2[i] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[0]
                 .dAdgbi_inv_dt.Link2[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Ji.Link2[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[0]
                 .Adgbi_inv.Link2[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_Link2[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link2[Kinematics_Transforms_tmp] =
          transforms_dt[0].dAdgbi_inv_dt.Link2[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link2[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    dJi_dt_Link3[i] = dv3[i];
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[0].dAdgbi_dt.Link2[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dv4[i] = d;
    dJi_dt_Link3[i + 6] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[0]
                 .dAdgbi_inv_dt.Link3[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Ji.Link3[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[0]
                 .Adgbi_inv.Link3[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_Link3[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link3[Kinematics_Transforms_tmp] =
          transforms_dt[0].dAdgbi_inv_dt.Link3[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link3[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    dJi_dt_Link4[i] = dv3[i];
    dJi_dt_Link4[i + 6] = dv4[i];
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[0].dAdgbi_dt.Link3[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dv5[i] = d;
    dJi_dt_Link4[i + 12] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[0]
                 .dAdgbi_inv_dt.Link4[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0]
                 .Ji.Link4[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[0]
                 .Adgbi_inv.Link4[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_Link4[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link4[Kinematics_Transforms_tmp] =
          transforms_dt[0].dAdgbi_inv_dt.Link4[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link4[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    dJi_dt_Link5[i] = dv3[i];
    dJi_dt_Link5[i + 6] = dv4[i];
    dJi_dt_Link5[i + 12] = dv5[i];
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[0].dAdgbi_dt.Link4[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dJi_dt_Link5[i + 18] = d;
  }
  std::copy(&dJi_dt_Link5[0], &dJi_dt_Link5[18], &dJi_dt_EE[0]);
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      d1 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        i2 = i + 6 * Kinematics_Transforms_tmp;
        i3 = Kinematics_Transforms_tmp + 6 * i1;
        d += transforms_dt[0].dAdgbi_inv_dt.Link5[i2] *
             Kinematics_Jacobians[0].Ji.Link5[i3];
        d1 += Kinematics_Transforms[0].Adgbi_inv.Link5[i2] * dJi_dt_Link5[i3];
      }
      Kinematics_Transforms_tmp = i + 6 * i1;
      d_Kinematics_Transforms[Kinematics_Transforms_tmp] = d1;
      b_transforms_dt[Kinematics_Transforms_tmp] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link5[Kinematics_Transforms_tmp] =
          transforms_dt[0].dAdgbi_inv_dt.Link5[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link5[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[0].dAdgbi_dt.EE[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dJi_dt_EE[i + 18] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[0]
                 .dAdgbi_inv_dt.EE[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[0].Ji.EE[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[0]
                 .Adgbi_inv.EE[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_EE[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].EE[Kinematics_Transforms_tmp] =
          transforms_dt[0].dAdgbi_inv_dt.EE[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].EE[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 60; i++) {
    dJbi_dts[0].Link1[i] = dJbi_dts[1].Link1[i];
    dJbi_dts[0].Link2[i] = dJbi_dts[1].Link2[i];
    dJbi_dts[0].Link3[i] = dJbi_dts[1].Link3[i];
    dJbi_dts[0].Link4[i] = dJbi_dts[1].Link4[i];
    dJbi_dts[0].Link5[i] = dJbi_dts[1].Link5[i];
    dJbi_dts[0].EE[i] = dJbi_dts[1].EE[i];
  }
  std::memset(&dJi_dt_Link2[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_Link3[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_Link4[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_Link5[0], 0, 24U * sizeof(double));
  std::memset(&dJi_dt_EE[0], 0, 24U * sizeof(double));
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      d1 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        i2 = i + 6 * Kinematics_Transforms_tmp;
        d += transforms_dt[1].dAdgbi_inv_dt.Link1[i2] *
             Kinematics_Jacobians[1]
                 .Ji.Link1[Kinematics_Transforms_tmp + 6 * i1];
        d1 += Kinematics_Transforms[1].Adgbi_inv.Link1[i2] * 0.0;
      }
      Kinematics_Transforms_tmp = i + 6 * i1;
      d_Kinematics_Transforms[Kinematics_Transforms_tmp] = d1;
      b_transforms_dt[Kinematics_Transforms_tmp] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link1[Kinematics_Transforms_tmp] =
          transforms_dt[1].dAdgbi_inv_dt.Link1[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link1[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[1].dAdgbi_dt.Link1[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dv3[i] = d;
    dJi_dt_Link2[i] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[1]
                 .dAdgbi_inv_dt.Link2[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Ji.Link2[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[1]
                 .Adgbi_inv.Link2[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_Link2[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link2[Kinematics_Transforms_tmp] =
          transforms_dt[1].dAdgbi_inv_dt.Link2[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link2[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    dJi_dt_Link3[i] = dv3[i];
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[1].dAdgbi_dt.Link2[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dv4[i] = d;
    dJi_dt_Link3[i + 6] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[1]
                 .dAdgbi_inv_dt.Link3[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Ji.Link3[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[1]
                 .Adgbi_inv.Link3[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_Link3[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link3[Kinematics_Transforms_tmp] =
          transforms_dt[1].dAdgbi_inv_dt.Link3[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link3[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    dJi_dt_Link4[i] = dv3[i];
    dJi_dt_Link4[i + 6] = dv4[i];
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[1].dAdgbi_dt.Link3[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dv5[i] = d;
    dJi_dt_Link4[i + 12] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[1]
                 .dAdgbi_inv_dt.Link4[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1]
                 .Ji.Link4[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[1]
                 .Adgbi_inv.Link4[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_Link4[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link4[Kinematics_Transforms_tmp] =
          transforms_dt[1].dAdgbi_inv_dt.Link4[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link4[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    dJi_dt_Link5[i] = dv3[i];
    dJi_dt_Link5[i + 6] = dv4[i];
    dJi_dt_Link5[i + 12] = dv5[i];
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[1].dAdgbi_dt.Link4[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dJi_dt_Link5[i + 18] = d;
  }
  std::copy(&dJi_dt_Link5[0], &dJi_dt_Link5[18], &dJi_dt_EE[0]);
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      d1 = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        i2 = i + 6 * Kinematics_Transforms_tmp;
        i3 = Kinematics_Transforms_tmp + 6 * i1;
        d += transforms_dt[1].dAdgbi_inv_dt.Link5[i2] *
             Kinematics_Jacobians[1].Ji.Link5[i3];
        d1 += Kinematics_Transforms[1].Adgbi_inv.Link5[i2] * dJi_dt_Link5[i3];
      }
      Kinematics_Transforms_tmp = i + 6 * i1;
      d_Kinematics_Transforms[Kinematics_Transforms_tmp] = d1;
      b_transforms_dt[Kinematics_Transforms_tmp] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].Link5[Kinematics_Transforms_tmp] =
          transforms_dt[1].dAdgbi_inv_dt.Link5[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].Link5[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      d += transforms_dt[1].dAdgbi_dt.EE[i + 6 * i1] *
           static_cast<double>(b_b[i1]);
    }
    dJi_dt_EE[i + 18] = d;
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += transforms_dt[1]
                 .dAdgbi_inv_dt.EE[i + 6 * Kinematics_Transforms_tmp] *
             Kinematics_Jacobians[1].Ji.EE[Kinematics_Transforms_tmp + 6 * i1];
      }
      b_transforms_dt[i + 6 * i1] = d;
    }
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 4; i1++) {
      d = 0.0;
      for (Kinematics_Transforms_tmp = 0; Kinematics_Transforms_tmp < 6;
           Kinematics_Transforms_tmp++) {
        d += Kinematics_Transforms[1]
                 .Adgbi_inv.EE[i + 6 * Kinematics_Transforms_tmp] *
             dJi_dt_EE[Kinematics_Transforms_tmp + 6 * i1];
      }
      d_Kinematics_Transforms[i + 6 * i1] = d;
    }
    for (i1 = 0; i1 < 6; i1++) {
      Kinematics_Transforms_tmp = i1 + 6 * i;
      dJbi_dts[1].EE[Kinematics_Transforms_tmp] =
          transforms_dt[1].dAdgbi_inv_dt.EE[Kinematics_Transforms_tmp];
    }
  }
  for (int i{0}; i < 24; i++) {
    dJbi_dts[1].EE[i + 36] = b_transforms_dt[i] + d_Kinematics_Transforms[i];
  }
}

//
// File trailer for calculateJacobiansTimeDerivative.cpp
//
// [EOF]
//
