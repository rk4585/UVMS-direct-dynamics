//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateHydrodynamicDamping.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "calculateHydrodynamicDamping.h"
#include "calculateMassMatrix.h"
#include "forward_dynamics_data.h"
#include "forward_dynamics_internal_types.h"
#include "forward_dynamics_types.h"
#include "mtimes.h"
#include "coder_array.h"
#include <cmath>
#include <cstring>

// Function Definitions
//
// Arguments    : const double params_CenterOfMass[3]
//                const double params_LinearDamping[36]
//                const double params_QuadraticDamping[36]
//                double params_NumDoFs
//                const double params_Arms_Arm1_Links_Link2_CenterOfMass[3]
//                const double params_Arms_Arm1_Links_Link2_LinearDamping[36]
//                const double params_Arms_Arm1_Links_Link2_QuadraticDamping[36]
//                const double params_Arms_Arm1_Links_Link3_CenterOfMass[3]
//                const double params_Arms_Arm1_Links_Link3_LinearDamping[36]
//                const double params_Arms_Arm1_Links_Link3_QuadraticDamping[36]
//                const double params_Arms_Arm1_Links_Link4_CenterOfMass[3]
//                const double params_Arms_Arm1_Links_Link4_LinearDamping[36]
//                const double params_Arms_Arm1_Links_Link4_QuadraticDamping[36]
//                const double params_Arms_Arm1_Links_Link5_CenterOfMass[3]
//                const double params_Arms_Arm1_Links_Link5_LinearDamping[36]
//                const double params_Arms_Arm1_Links_Link5_QuadraticDamping[36]
//                const struct5_T &params_Arms_Arm2_Links_Link2
//                const struct5_T &params_Arms_Arm2_Links_Link3
//                const struct5_T &params_Arms_Arm2_Links_Link4
//                const struct5_T &params_Arms_Arm2_Links_Link5
//                const double zeta[14]
//                const d_struct_T Kinematics_Jacobians[2]
//                coder::array<double, 2U> &D
// Return Type  : void
//
void calculateHydrodynamicDamping(
    const double params_CenterOfMass[3], const double params_LinearDamping[36],
    const double params_QuadraticDamping[36], double params_NumDoFs,
    const double params_Arms_Arm1_Links_Link2_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link2_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link2_QuadraticDamping[36],
    const double params_Arms_Arm1_Links_Link3_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link3_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link3_QuadraticDamping[36],
    const double params_Arms_Arm1_Links_Link4_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link4_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link4_QuadraticDamping[36],
    const double params_Arms_Arm1_Links_Link5_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link5_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link5_QuadraticDamping[36],
    const struct5_T &params_Arms_Arm2_Links_Link2,
    const struct5_T &params_Arms_Arm2_Links_Link3,
    const struct5_T &params_Arms_Arm2_Links_Link4,
    const struct5_T &params_Arms_Arm2_Links_Link5, const double zeta[14],
    const d_struct_T Kinematics_Jacobians[2], coder::array<double, 2U> &D)
{
  coder::array<double, 2U> C;
  coder::array<double, 2U> J;
  coder::array<double, 2U> Jvehicle;
  coder::array<double, 2U> b_y;
  coder::array<double, 2U> r;
  double Adgici[36];
  double b[36];
  double b_params_LinearDamping[36];
  double y[6];
  double s;
  int coffset_tmp;
  int loop_ub;
  int loop_ub_tmp;
  std::memset(&Adgici[0], 0, 36U * sizeof(double));
  for (int k{0}; k < 6; k++) {
    Adgici[k + 6 * k] = 1.0;
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs - 6.0) + 6);
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      Jvehicle[coffset_tmp + 6 * j] = Adgici[coffset_tmp + 6 * j];
    }
  }
  loop_ub = static_cast<int>(params_NumDoFs - 6.0);
  for (int j{0}; j < loop_ub; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      Jvehicle[coffset_tmp + 6 * (j + 6)] = 0.0;
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_CenterOfMass[2];
  Adgici[30] = params_CenterOfMass[1];
  Adgici[19] = params_CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_CenterOfMass[0];
  Adgici[20] = -params_CenterOfMass[1];
  Adgici[26] = params_CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = Jvehicle.size(1);
  C.set_size(6, Jvehicle.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * Jvehicle[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] = params_LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(Jvehicle, b, b_y);
  J.set_size(6, static_cast<int>(params_NumDoFs));
  loop_ub_tmp = 6 * static_cast<int>(params_NumDoFs);
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[0].Jb.Link2[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link2[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm1_Links_Link2_CenterOfMass[2];
  Adgici[30] = params_Arms_Arm1_Links_Link2_CenterOfMass[1];
  Adgici[19] = params_Arms_Arm1_Links_Link2_CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm1_Links_Link2_CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm1_Links_Link2_CenterOfMass[1];
  Adgici[26] = params_Arms_Arm1_Links_Link2_CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  coder::internal::blas::mtimes(b_y, Jvehicle, D);
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm1_Links_Link2_QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm1_Links_Link2_LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[0].Jb.Link3[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link3[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm1_Links_Link3_CenterOfMass[2];
  Adgici[30] = params_Arms_Arm1_Links_Link3_CenterOfMass[1];
  Adgici[19] = params_Arms_Arm1_Links_Link3_CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm1_Links_Link3_CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm1_Links_Link3_CenterOfMass[1];
  Adgici[26] = params_Arms_Arm1_Links_Link3_CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm1_Links_Link3_QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm1_Links_Link3_LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[0].Jb.Link4[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link4[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm1_Links_Link4_CenterOfMass[2];
  Adgici[30] = params_Arms_Arm1_Links_Link4_CenterOfMass[1];
  Adgici[19] = params_Arms_Arm1_Links_Link4_CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm1_Links_Link4_CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm1_Links_Link4_CenterOfMass[1];
  Adgici[26] = params_Arms_Arm1_Links_Link4_CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm1_Links_Link4_QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm1_Links_Link4_LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[0].Jb.Link5[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 6)] =
          Kinematics_Jacobians[0].Jb.Link5[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm1_Links_Link5_CenterOfMass[2];
  Adgici[30] = params_Arms_Arm1_Links_Link5_CenterOfMass[1];
  Adgici[19] = params_Arms_Arm1_Links_Link5_CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm1_Links_Link5_CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm1_Links_Link5_CenterOfMass[1];
  Adgici[26] = params_Arms_Arm1_Links_Link5_CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm1_Links_Link5_QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm1_Links_Link5_LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[1].Jb.Link2[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link2[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm2_Links_Link2.CenterOfMass[2];
  Adgici[30] = params_Arms_Arm2_Links_Link2.CenterOfMass[1];
  Adgici[19] = params_Arms_Arm2_Links_Link2.CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm2_Links_Link2.CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm2_Links_Link2.CenterOfMass[1];
  Adgici[26] = params_Arms_Arm2_Links_Link2.CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm2_Links_Link2.QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm2_Links_Link2.LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[1].Jb.Link3[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link3[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm2_Links_Link3.CenterOfMass[2];
  Adgici[30] = params_Arms_Arm2_Links_Link3.CenterOfMass[1];
  Adgici[19] = params_Arms_Arm2_Links_Link3.CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm2_Links_Link3.CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm2_Links_Link3.CenterOfMass[1];
  Adgici[26] = params_Arms_Arm2_Links_Link3.CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm2_Links_Link3.QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm2_Links_Link3.LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[1].Jb.Link4[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link4[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm2_Links_Link4.CenterOfMass[2];
  Adgici[30] = params_Arms_Arm2_Links_Link4.CenterOfMass[1];
  Adgici[19] = params_Arms_Arm2_Links_Link4.CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm2_Links_Link4.CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm2_Links_Link4.CenterOfMass[1];
  Adgici[26] = params_Arms_Arm2_Links_Link4.CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm2_Links_Link4.QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm2_Links_Link4.LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
  J.set_size(6, static_cast<int>(params_NumDoFs));
  for (int j{0}; j < loop_ub_tmp; j++) {
    J[j] = 0.0;
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * j] =
          Kinematics_Jacobians[1].Jb.Link5[coffset_tmp + 6 * j];
    }
  }
  for (int j{0}; j < 4; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      J[coffset_tmp + 6 * (j + 10)] =
          Kinematics_Jacobians[1].Jb.Link5[coffset_tmp + 6 * (j + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int j{0}; j < 3; j++) {
    Adgici[6 * j] = iv1[3 * j];
    Adgici[6 * j + 1] = iv1[3 * j + 1];
    Adgici[6 * j + 2] = iv1[3 * j + 2];
  }
  Adgici[18] = 0.0;
  Adgici[24] = -params_Arms_Arm2_Links_Link5.CenterOfMass[2];
  Adgici[30] = params_Arms_Arm2_Links_Link5.CenterOfMass[1];
  Adgici[19] = params_Arms_Arm2_Links_Link5.CenterOfMass[2];
  Adgici[25] = 0.0;
  Adgici[31] = -params_Arms_Arm2_Links_Link5.CenterOfMass[0];
  Adgici[20] = -params_Arms_Arm2_Links_Link5.CenterOfMass[1];
  Adgici[26] = params_Arms_Arm2_Links_Link5.CenterOfMass[0];
  Adgici[32] = 0.0;
  for (int j{0}; j < 6; j++) {
    Adgici[6 * j + 3] = iv[3 * j];
    Adgici[6 * j + 4] = iv[3 * j + 1];
    Adgici[6 * j + 5] = iv[3 * j + 2];
  }
  loop_ub = J.size(1);
  C.set_size(6, J.size(1));
  for (int j{0}; j < loop_ub; j++) {
    coffset_tmp = j * 6;
    for (int i{0}; i < 6; i++) {
      s = 0.0;
      for (int k{0}; k < 6; k++) {
        s += Adgici[k * 6 + i] * J[coffset_tmp + k];
      }
      C[coffset_tmp + i] = s;
    }
  }
  for (int k{0}; k < 6; k++) {
    s = 0.0;
    for (int j{0}; j < 14; j++) {
      s += C[k + 6 * j] * zeta[j];
    }
    y[k] = std::abs(s);
  }
  std::memset(&b[0], 0, 36U * sizeof(double));
  for (int j{0}; j < 6; j++) {
    b[j + 6 * j] = y[j];
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += params_Arms_Arm2_Links_Link5.QuadraticDamping[j + 6 * loop_ub] *
             b[loop_ub + 6 * coffset_tmp];
      }
      loop_ub = j + 6 * coffset_tmp;
      b_params_LinearDamping[loop_ub] =
          params_Arms_Arm2_Links_Link5.LinearDamping[loop_ub] + s;
    }
  }
  for (int j{0}; j < 6; j++) {
    for (coffset_tmp = 0; coffset_tmp < 6; coffset_tmp++) {
      s = 0.0;
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        s += Adgici[loop_ub + 6 * j] *
             b_params_LinearDamping[loop_ub + 6 * coffset_tmp];
      }
      b[j + 6 * coffset_tmp] = s;
    }
  }
  coder::internal::blas::mtimes(J, b, b_y);
  coder::internal::blas::mtimes(b_y, J, r);
  if ((D.size(0) == r.size(0)) && (D.size(1) == r.size(1))) {
    loop_ub = D.size(0) * D.size(1);
    for (int j{0}; j < loop_ub; j++) {
      D[j] = D[j] + r[j];
    }
  } else {
    plus(D, r);
  }
}

//
// File trailer for calculateHydrodynamicDamping.cpp
//
// [EOF]
//
