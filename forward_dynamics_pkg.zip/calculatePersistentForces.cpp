//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculatePersistentForces.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "calculatePersistentForces.h"
#include "forward_dynamics_data.h"
#include "forward_dynamics_internal_types.h"
#include "forward_dynamics_types.h"
#include "coder_array.h"
#include <cmath>

// Function Declarations
static void plus(coder::array<double, 1U> &in1,
                 const coder::array<double, 1U> &in2);

// Function Definitions
//
// Arguments    : coder::array<double, 1U> &in1
//                const coder::array<double, 1U> &in2
// Return Type  : void
//
static void plus(coder::array<double, 1U> &in1,
                 const coder::array<double, 1U> &in2)
{
  coder::array<double, 1U> b_in1;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in2.size(0) != 1);
  for (int i{0}; i < loop_ub; i++) {
    b_in1[i] = in1[i * stride_0_0] + in2[i * stride_1_0];
  }
  in1.set_size(b_in1.size(0));
  loop_ub = b_in1.size(0);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = b_in1[i];
  }
}

//
// Arguments    : double params_Mass
//                const double params_CenterOfMass[3]
//                double params_Volume
//                const double params_CenterOfBuoyancy[3]
//                double params_NumDoFs
//                double params_g
//                double params_rho
//                double params_Arms_Arm1_Links_Link2_Mass
//                const double params_Arms_Arm1_Links_Link2_CenterOfMass[3]
//                double params_Arms_Arm1_Links_Link2_Volume
//                const double params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[3]
//                double params_Arms_Arm1_Links_Link3_Mass
//                const double params_Arms_Arm1_Links_Link3_CenterOfMass[3]
//                double params_Arms_Arm1_Links_Link3_Volume
//                const double params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[3]
//                const struct5_T &params_Arms_Arm1_Links_Link4
//                const struct5_T &params_Arms_Arm1_Links_Link5
//                const struct5_T &params_Arms_Arm2_Links_Link2
//                const struct5_T &params_Arms_Arm2_Links_Link3
//                const struct5_T &params_Arms_Arm2_Links_Link4
//                const struct5_T &params_Arms_Arm2_Links_Link5
//                const double ksi[14]
//                const d_struct_T Kinematics_Jacobians[2]
//                const h_struct_T Kinematics_Transforms[2]
//                coder::array<double, 1U> &N_p
// Return Type  : void
//
void calculatePersistentForces(
    double params_Mass, const double params_CenterOfMass[3],
    double params_Volume, const double params_CenterOfBuoyancy[3],
    double params_NumDoFs, double params_g, double params_rho,
    double params_Arms_Arm1_Links_Link2_Mass,
    const double params_Arms_Arm1_Links_Link2_CenterOfMass[3],
    double params_Arms_Arm1_Links_Link2_Volume,
    const double params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[3],
    double params_Arms_Arm1_Links_Link3_Mass,
    const double params_Arms_Arm1_Links_Link3_CenterOfMass[3],
    double params_Arms_Arm1_Links_Link3_Volume,
    const double params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[3],
    const struct5_T &params_Arms_Arm1_Links_Link4,
    const struct5_T &params_Arms_Arm1_Links_Link5,
    const struct5_T &params_Arms_Arm2_Links_Link2,
    const struct5_T &params_Arms_Arm2_Links_Link3,
    const struct5_T &params_Arms_Arm2_Links_Link4,
    const struct5_T &params_Arms_Arm2_Links_Link5, const double ksi[14],
    const d_struct_T Kinematics_Jacobians[2],
    const h_struct_T Kinematics_Transforms[2], coder::array<double, 1U> &N_p)
{
  static const signed char b[3]{0, 0, 1};
  static const signed char b_iv[3]{1, 0, 0};
  coder::array<double, 2U> Jvehicle;
  coder::array<double, 1U> r;
  double dv[36];
  double dv1[36];
  double Ri0[9];
  double c_Rz_tmp[9];
  double d_Rz_tmp[9];
  double Fip[6];
  double a[6];
  double b_a[6];
  double Rx_tmp;
  double Ry_tmp;
  double Rz_tmp;
  double b_Rx_tmp;
  double b_Rz_tmp;
  double d;
  double d1;
  double s;
  int aoffset;
  int b_i;
  int i1;
  int k;
  int loop_ub;
  int loop_ub_tmp;
  signed char b_I[36];
  signed char i2;
  for (int i{0}; i < 36; i++) {
    b_I[i] = 0;
  }
  for (k = 0; k < 6; k++) {
    b_I[k + 6 * k] = 1;
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs - 6.0) + 6);
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = b_I[i1 + 6 * i];
    }
  }
  loop_ub = static_cast<int>(params_NumDoFs - 6.0);
  for (int i{0}; i < loop_ub; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 6)] = 0.0;
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  Rx_tmp = std::sin(ksi[3]);
  b_Rx_tmp = std::cos(ksi[3]);
  s = std::sin(ksi[4]);
  Ry_tmp = std::cos(ksi[4]);
  Rz_tmp = std::sin(ksi[5]);
  b_Rz_tmp = std::cos(ksi[5]);
  c_Rz_tmp[0] = b_Rz_tmp;
  c_Rz_tmp[3] = -Rz_tmp;
  c_Rz_tmp[6] = 0.0;
  c_Rz_tmp[1] = Rz_tmp;
  c_Rz_tmp[4] = b_Rz_tmp;
  c_Rz_tmp[7] = 0.0;
  Ri0[0] = Ry_tmp;
  Ri0[3] = 0.0;
  Ri0[6] = s;
  c_Rz_tmp[2] = 0.0;
  Ri0[1] = 0.0;
  c_Rz_tmp[5] = 0.0;
  Ri0[4] = 1.0;
  c_Rz_tmp[8] = 1.0;
  Ri0[7] = 0.0;
  Ri0[2] = -s;
  Ri0[5] = 0.0;
  Ri0[8] = Ry_tmp;
  for (int i{0}; i < 3; i++) {
    d = c_Rz_tmp[i];
    d1 = c_Rz_tmp[i + 3];
    i1 = static_cast<int>(c_Rz_tmp[i + 6]);
    for (b_i = 0; b_i < 3; b_i++) {
      d_Rz_tmp[i + 3 * b_i] = (d * Ri0[3 * b_i] + d1 * Ri0[3 * b_i + 1]) +
                              static_cast<double>(i1) * Ri0[3 * b_i + 2];
    }
  }
  c_Rz_tmp[1] = 0.0;
  c_Rz_tmp[4] = b_Rx_tmp;
  c_Rz_tmp[7] = -Rx_tmp;
  c_Rz_tmp[2] = 0.0;
  c_Rz_tmp[5] = Rx_tmp;
  c_Rz_tmp[8] = b_Rx_tmp;
  s = -params_Mass * params_g;
  Ry_tmp = params_rho * params_Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_CenterOfMass[2];
  dv[5] = params_CenterOfMass[1];
  dv[9] = params_CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_CenterOfMass[0];
  dv[15] = -params_CenterOfMass[1];
  dv[16] = params_CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_CenterOfBuoyancy[2];
  dv1[5] = params_CenterOfBuoyancy[1];
  dv1[9] = params_CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_CenterOfBuoyancy[0];
  dv1[15] = -params_CenterOfBuoyancy[1];
  dv1[16] = params_CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = b_iv[i];
    c_Rz_tmp[3 * i] = i1;
    d = c_Rz_tmp[3 * i + 1];
    d1 = c_Rz_tmp[3 * i + 2];
    Rz_tmp = 0.0;
    for (b_i = 0; b_i < 3; b_i++) {
      b_Rz_tmp =
          (d_Rz_tmp[b_i] * static_cast<double>(i1) + d_Rz_tmp[b_i + 3] * d) +
          d_Rz_tmp[b_i + 6] * d1;
      loop_ub = i + 3 * b_i;
      Ri0[loop_ub] = b_Rz_tmp;
      Rz_tmp += s * b_Rz_tmp * static_cast<double>(b[b_i]);
      dv[b_i + 6 * i] = iv1[loop_ub];
    }
    a[i] = Rz_tmp;
    dv1[6 * i] = iv1[i];
    dv1[6 * i + 1] = iv1[i + 3];
    dv1[6 * i + 2] = iv1[i + 6];
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Ri0[i] * 0.0 + Ry_tmp * Ri0[i + 3] * 0.0) +
             Ry_tmp * Ri0[i + 6];
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  N_p.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    N_p[b_i] = s;
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  loop_ub_tmp = 6 * static_cast<int>(params_NumDoFs);
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[0].Jb.Link2[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 6)] =
          Kinematics_Jacobians[0].Jb.Link2[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[0].R0i.Link2[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[0].R0i.Link2[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[0].R0i.Link2[i + 6];
  }
  s = -params_Arms_Arm1_Links_Link2_Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm1_Links_Link2_Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm1_Links_Link2_CenterOfMass[2];
  dv[5] = params_Arms_Arm1_Links_Link2_CenterOfMass[1];
  dv[9] = params_Arms_Arm1_Links_Link2_CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm1_Links_Link2_CenterOfMass[0];
  dv[15] = -params_Arms_Arm1_Links_Link2_CenterOfMass[1];
  dv[16] = params_Arms_Arm1_Links_Link2_CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[0].Jb.Link3[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 6)] =
          Kinematics_Jacobians[0].Jb.Link3[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[0].R0i.Link3[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[0].R0i.Link3[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[0].R0i.Link3[i + 6];
  }
  s = -params_Arms_Arm1_Links_Link3_Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm1_Links_Link3_Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm1_Links_Link3_CenterOfMass[2];
  dv[5] = params_Arms_Arm1_Links_Link3_CenterOfMass[1];
  dv[9] = params_Arms_Arm1_Links_Link3_CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm1_Links_Link3_CenterOfMass[0];
  dv[15] = -params_Arms_Arm1_Links_Link3_CenterOfMass[1];
  dv[16] = params_Arms_Arm1_Links_Link3_CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[0].Jb.Link4[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 6)] =
          Kinematics_Jacobians[0].Jb.Link4[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[0].R0i.Link4[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[0].R0i.Link4[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[0].R0i.Link4[i + 6];
  }
  s = -params_Arms_Arm1_Links_Link4.Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm1_Links_Link4.Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm1_Links_Link4.CenterOfMass[2];
  dv[5] = params_Arms_Arm1_Links_Link4.CenterOfMass[1];
  dv[9] = params_Arms_Arm1_Links_Link4.CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm1_Links_Link4.CenterOfMass[0];
  dv[15] = -params_Arms_Arm1_Links_Link4.CenterOfMass[1];
  dv[16] = params_Arms_Arm1_Links_Link4.CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm1_Links_Link4.CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm1_Links_Link4.CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm1_Links_Link4.CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm1_Links_Link4.CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm1_Links_Link4.CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm1_Links_Link4.CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[0].Jb.Link5[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 6)] =
          Kinematics_Jacobians[0].Jb.Link5[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[0].R0i.Link5[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[0].R0i.Link5[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[0].R0i.Link5[i + 6];
  }
  s = -params_Arms_Arm1_Links_Link5.Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm1_Links_Link5.Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm1_Links_Link5.CenterOfMass[2];
  dv[5] = params_Arms_Arm1_Links_Link5.CenterOfMass[1];
  dv[9] = params_Arms_Arm1_Links_Link5.CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm1_Links_Link5.CenterOfMass[0];
  dv[15] = -params_Arms_Arm1_Links_Link5.CenterOfMass[1];
  dv[16] = params_Arms_Arm1_Links_Link5.CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm1_Links_Link5.CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm1_Links_Link5.CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm1_Links_Link5.CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm1_Links_Link5.CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm1_Links_Link5.CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm1_Links_Link5.CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[1].Jb.Link2[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 10)] =
          Kinematics_Jacobians[1].Jb.Link2[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[1].R0i.Link2[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[1].R0i.Link2[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[1].R0i.Link2[i + 6];
  }
  s = -params_Arms_Arm2_Links_Link2.Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm2_Links_Link2.Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm2_Links_Link2.CenterOfMass[2];
  dv[5] = params_Arms_Arm2_Links_Link2.CenterOfMass[1];
  dv[9] = params_Arms_Arm2_Links_Link2.CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm2_Links_Link2.CenterOfMass[0];
  dv[15] = -params_Arms_Arm2_Links_Link2.CenterOfMass[1];
  dv[16] = params_Arms_Arm2_Links_Link2.CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm2_Links_Link2.CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm2_Links_Link2.CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm2_Links_Link2.CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm2_Links_Link2.CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm2_Links_Link2.CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm2_Links_Link2.CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[1].Jb.Link3[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 10)] =
          Kinematics_Jacobians[1].Jb.Link3[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[1].R0i.Link3[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[1].R0i.Link3[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[1].R0i.Link3[i + 6];
  }
  s = -params_Arms_Arm2_Links_Link3.Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm2_Links_Link3.Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm2_Links_Link3.CenterOfMass[2];
  dv[5] = params_Arms_Arm2_Links_Link3.CenterOfMass[1];
  dv[9] = params_Arms_Arm2_Links_Link3.CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm2_Links_Link3.CenterOfMass[0];
  dv[15] = -params_Arms_Arm2_Links_Link3.CenterOfMass[1];
  dv[16] = params_Arms_Arm2_Links_Link3.CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm2_Links_Link3.CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm2_Links_Link3.CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm2_Links_Link3.CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm2_Links_Link3.CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm2_Links_Link3.CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm2_Links_Link3.CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[1].Jb.Link4[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 10)] =
          Kinematics_Jacobians[1].Jb.Link4[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[1].R0i.Link4[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[1].R0i.Link4[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[1].R0i.Link4[i + 6];
  }
  s = -params_Arms_Arm2_Links_Link4.Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm2_Links_Link4.Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm2_Links_Link4.CenterOfMass[2];
  dv[5] = params_Arms_Arm2_Links_Link4.CenterOfMass[1];
  dv[9] = params_Arms_Arm2_Links_Link4.CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm2_Links_Link4.CenterOfMass[0];
  dv[15] = -params_Arms_Arm2_Links_Link4.CenterOfMass[1];
  dv[16] = params_Arms_Arm2_Links_Link4.CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm2_Links_Link4.CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm2_Links_Link4.CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm2_Links_Link4.CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm2_Links_Link4.CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm2_Links_Link4.CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm2_Links_Link4.CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
  Jvehicle.set_size(6, static_cast<int>(params_NumDoFs));
  for (int i{0}; i < loop_ub_tmp; i++) {
    Jvehicle[i] = 0.0;
  }
  for (int i{0}; i < 6; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * i] = Kinematics_Jacobians[1].Jb.Link5[i1 + 6 * i];
    }
  }
  for (int i{0}; i < 4; i++) {
    for (i1 = 0; i1 < 6; i1++) {
      Jvehicle[i1 + 6 * (i + 10)] =
          Kinematics_Jacobians[1].Jb.Link5[i1 + 6 * (i + 6)];
    }
  }
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  //  Ensure the vector is a 1x3 or 3x1 vector
  //  Convert any vector to a 1x3 row vector for uniformity
  //  Create the skew-symmetric matrix
  for (int i{0}; i < 3; i++) {
    Ri0[3 * i] = Kinematics_Transforms[1].R0i.Link5[i];
    Ri0[3 * i + 1] = Kinematics_Transforms[1].R0i.Link5[i + 3];
    Ri0[3 * i + 2] = Kinematics_Transforms[1].R0i.Link5[i + 6];
  }
  s = -params_Arms_Arm2_Links_Link5.Mass * params_g;
  Ry_tmp = params_rho * params_Arms_Arm2_Links_Link5.Volume * params_g;
  dv[3] = 0.0;
  dv[4] = -params_Arms_Arm2_Links_Link5.CenterOfMass[2];
  dv[5] = params_Arms_Arm2_Links_Link5.CenterOfMass[1];
  dv[9] = params_Arms_Arm2_Links_Link5.CenterOfMass[2];
  dv[10] = 0.0;
  dv[11] = -params_Arms_Arm2_Links_Link5.CenterOfMass[0];
  dv[15] = -params_Arms_Arm2_Links_Link5.CenterOfMass[1];
  dv[16] = params_Arms_Arm2_Links_Link5.CenterOfMass[0];
  dv[17] = 0.0;
  a[3] = 0.0;
  a[4] = 0.0;
  a[5] = 0.0;
  dv1[3] = 0.0;
  dv1[4] = -params_Arms_Arm2_Links_Link5.CenterOfBuoyancy[2];
  dv1[5] = params_Arms_Arm2_Links_Link5.CenterOfBuoyancy[1];
  dv1[9] = params_Arms_Arm2_Links_Link5.CenterOfBuoyancy[2];
  dv1[10] = 0.0;
  dv1[11] = -params_Arms_Arm2_Links_Link5.CenterOfBuoyancy[0];
  dv1[15] = -params_Arms_Arm2_Links_Link5.CenterOfBuoyancy[1];
  dv1[16] = params_Arms_Arm2_Links_Link5.CenterOfBuoyancy[0];
  dv1[17] = 0.0;
  for (int i{0}; i < 3; i++) {
    i1 = iv1[i];
    dv[6 * i] = i1;
    d = Ri0[i + 3];
    b_i = iv1[i + 3];
    loop_ub = 6 * i + 1;
    dv[loop_ub] = b_i;
    d1 = Ri0[i + 6];
    aoffset = iv1[i + 6];
    k = 6 * i + 2;
    dv[k] = aoffset;
    Rz_tmp = Ri0[i];
    a[i] = (s * Rz_tmp * 0.0 + s * d * 0.0) + s * d1;
    dv1[6 * i] = i1;
    dv1[loop_ub] = b_i;
    dv1[k] = aoffset;
    for (i1 = 0; i1 < 6; i1++) {
      i2 = iv[i + 3 * i1];
      b_i = i1 + 6 * (i + 3);
      dv[b_i] = i2;
      dv1[b_i] = i2;
    }
    b_a[i] = (Ry_tmp * Rz_tmp * 0.0 + Ry_tmp * d * 0.0) + Ry_tmp * d1;
  }
  b_a[3] = 0.0;
  b_a[4] = 0.0;
  b_a[5] = 0.0;
  for (int i{0}; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      b_i = i + 6 * i1;
      d += dv[b_i] * a[i1];
      d1 += dv1[b_i] * b_a[i1];
    }
    Fip[i] = d + d1;
  }
  loop_ub = Jvehicle.size(1);
  r.set_size(Jvehicle.size(1));
  for (b_i = 0; b_i < loop_ub; b_i++) {
    aoffset = b_i * 6;
    s = 0.0;
    for (k = 0; k < 6; k++) {
      s += Jvehicle[aoffset + k] * Fip[k];
    }
    r[b_i] = s;
  }
  if (N_p.size(0) == r.size(0)) {
    loop_ub = N_p.size(0);
    for (int i{0}; i < loop_ub; i++) {
      N_p[i] = N_p[i] + r[i];
    }
  } else {
    plus(N_p, r);
  }
}

//
// File trailer for calculatePersistentForces.cpp
//
// [EOF]
//
