//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "forward_dynamics.h"
#include "calculateCoriolisMatrix.h"
#include "calculateHydrodynamicDamping.h"
#include "calculateMassMatrix.h"
#include "calculatePersistentForces.h"
#include "calculateTransforms.h"
#include "forward_dynamics_internal_types.h"
#include "forward_dynamics_types.h"
#include "mldivide.h"
#include "mtimes.h"
#include "coder_array.h"
#include <algorithm>
#include <cmath>
#include <cstring>

// Function Declarations
static void binary_expand_op(coder::array<double, 2U> &in1,
                             const coder::array<double, 2U> &in2);

static int binary_expand_op(double in1_data[],
                            const coder::array<double, 2U> &in2,
                            const coder::array<double, 1U> &in3,
                            const coder::array<double, 1U> &in4,
                            const coder::array<double, 1U> &in5);

// Function Definitions
//
// Arguments    : coder::array<double, 2U> &in1
//                const coder::array<double, 2U> &in2
// Return Type  : void
//
static void binary_expand_op(coder::array<double, 2U> &in1,
                             const coder::array<double, 2U> &in2)
{
  coder::array<double, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          -(in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] +
            in2[i1 * stride_1_0 + in2.size(0) * aux_1_1]);
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

//
// Arguments    : double in1_data[]
//                const coder::array<double, 2U> &in2
//                const coder::array<double, 1U> &in3
//                const coder::array<double, 1U> &in4
//                const coder::array<double, 1U> &in5
// Return Type  : int
//
static int binary_expand_op(double in1_data[],
                            const coder::array<double, 2U> &in2,
                            const coder::array<double, 1U> &in3,
                            const coder::array<double, 1U> &in4,
                            const coder::array<double, 1U> &in5)
{
  coder::array<double, 1U> b_in3;
  double b_in2[196];
  int aux_0_1;
  int stride_0_0;
  int stride_0_1;
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  for (int i{0}; i < 14; i++) {
    for (int i1{0}; i1 < 14; i1++) {
      b_in2[i1 + 14 * i] = in2[i1 * stride_0_0 + in2.size(0) * aux_0_1];
    }
    aux_0_1 += stride_0_1;
  }
  b_in3.set_size(in5.size(0));
  stride_0_0 = (in3.size(0) != 1);
  stride_0_1 = (in4.size(0) != 1);
  aux_0_1 = in5.size(0);
  for (int i{0}; i < aux_0_1; i++) {
    b_in3[i] = (in3[i * stride_0_0] - in4[i * stride_0_1]) + in5[i];
  }
  return coder::mldivide(b_in2, b_in3, in1_data);
}

//
// Arguments    : const struct0_T *params
//                const double ksi[14]
//                const double zeta[14]
//                const double control_input[15]
//                double dksi_dt[14]
//                double dzeta_dt_data[]
//                int dzeta_dt_size[1]
// Return Type  : void
//
void forward_dynamics(const struct0_T *params, const double ksi[14],
                      const double zeta[14], const double control_input[15],
                      double dksi_dt[14], double dzeta_dt_data[],
                      int dzeta_dt_size[1])
{
  static const signed char b_iv[112]{
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
      0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1};
  static const signed char b[6]{0, 0, 0, 0, 0, 1};
  coder::array<double, 2U> C;
  coder::array<double, 2U> D;
  coder::array<double, 2U> Jbi;
  coder::array<double, 2U> Jvehicle;
  coder::array<double, 2U> M;
  coder::array<double, 2U> r;
  coder::array<double, 1U> N;
  coder::array<double, 1U> b_C;
  coder::array<double, 1U> c_C;
  b_struct_T Jbs[2];
  c_struct_T Ji[2];
  d_struct_T Jacobians[2];
  h_struct_T transforms[2];
  double c_R_0_B_tmp[196];
  double d_d[36];
  double b_transforms[24];
  double b_d[9];
  double c_d[9];
  double v[3];
  double R_0_B_tmp;
  double R_0_B_tmp_tmp;
  double S_0_B_tmp;
  double b_R_0_B_tmp;
  double b_R_0_B_tmp_tmp;
  double c_R_0_B_tmp_tmp;
  double d;
  double d1;
  double d2;
  double d_R_0_B_tmp_tmp;
  double t;
  int aoffset;
  int d_tmp;
  int i;
  int j;
  int k;
  int loop_ub;
  int loop_ub_tmp;
  signed char b_I[36];
  calculateTransforms(
      params->Arms.Arm1.TransformVehicleToArmBase,
      params->Arms.Arm1.LastLinkToEE, params->Arms.Arm1.DHParameters.d,
      params->Arms.Arm1.DHParameters.theta, params->Arms.Arm1.DHParameters.a,
      params->Arms.Arm1.DHParameters.alpha,
      params->Arms.Arm2.TransformVehicleToArmBase,
      params->Arms.Arm2.LastLinkToEE, params->Arms.Arm2.DHParameters.d,
      params->Arms.Arm2.DHParameters.theta, params->Arms.Arm2.DHParameters.a,
      params->Arms.Arm2.DHParameters.alpha, ksi, transforms);
  std::memset(&Ji[1].Link2[0], 0, 24U * sizeof(double));
  std::memset(&Ji[1].Link3[0], 0, 24U * sizeof(double));
  std::memset(&Ji[1].Link4[0], 0, 24U * sizeof(double));
  std::memset(&Ji[1].Link5[0], 0, 24U * sizeof(double));
  std::memset(&Ji[1].EE[0], 0, 24U * sizeof(double));
  t = 0.0;
  R_0_B_tmp_tmp = 0.0;
  R_0_B_tmp = 0.0;
  b_R_0_B_tmp = 0.0;
  b_R_0_B_tmp_tmp = 0.0;
  c_R_0_B_tmp_tmp = 0.0;
  for (i = 0; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    d2 = 0.0;
    S_0_B_tmp = 0.0;
    d_R_0_B_tmp_tmp = 0.0;
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = i + 6 * aoffset;
      loop_ub = b[aoffset];
      d += transforms[0].Adgbi.Link1[j] * static_cast<double>(loop_ub);
      t = d;
      d1 += transforms[0].Adgbi.Link2[j] * static_cast<double>(loop_ub);
      R_0_B_tmp_tmp = d;
      R_0_B_tmp = d1;
      d2 += transforms[0].Adgbi.Link3[j] * static_cast<double>(loop_ub);
      b_R_0_B_tmp = d;
      b_R_0_B_tmp_tmp = d1;
      c_R_0_B_tmp_tmp = d2;
      S_0_B_tmp += transforms[0].Adgbi.Link4[j] * static_cast<double>(loop_ub);
      d_R_0_B_tmp_tmp +=
          transforms[0].Adgbi.EE[j] * static_cast<double>(loop_ub);
    }
    Ji[1].EE[i + 18] = d_R_0_B_tmp_tmp;
    Ji[1].Link5[i + 18] = S_0_B_tmp;
    Ji[1].Link5[i + 12] = c_R_0_B_tmp_tmp;
    Ji[1].Link5[i + 6] = b_R_0_B_tmp_tmp;
    Ji[1].Link5[i] = b_R_0_B_tmp;
    Ji[1].Link4[i + 12] = d2;
    Ji[1].Link4[i + 6] = R_0_B_tmp;
    Ji[1].Link4[i] = R_0_B_tmp_tmp;
    Ji[1].Link3[i + 6] = d1;
    Ji[1].Link3[i] = t;
    Ji[1].Link2[i] = d;
  }
  for (i = 0; i < 24; i++) {
    Ji[0].Link1[i] = 0.0;
    Ji[0].Link2[i] = Ji[1].Link2[i];
    Ji[0].Link3[i] = Ji[1].Link3[i];
    Ji[0].Link4[i] = Ji[1].Link4[i];
    Ji[0].Link5[i] = Ji[1].Link5[i];
    Ji[0].EE[i] = Ji[1].EE[i];
    Ji[1].Link2[i] = 0.0;
    Ji[1].Link3[i] = 0.0;
    Ji[1].Link4[i] = 0.0;
    Ji[1].Link5[i] = 0.0;
    Ji[1].EE[i] = 0.0;
  }
  t = 0.0;
  R_0_B_tmp_tmp = 0.0;
  R_0_B_tmp = 0.0;
  b_R_0_B_tmp = 0.0;
  b_R_0_B_tmp_tmp = 0.0;
  c_R_0_B_tmp_tmp = 0.0;
  for (i = 0; i < 6; i++) {
    d = 0.0;
    d1 = 0.0;
    d2 = 0.0;
    S_0_B_tmp = 0.0;
    d_R_0_B_tmp_tmp = 0.0;
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = i + 6 * aoffset;
      loop_ub = b[aoffset];
      d += transforms[1].Adgbi.Link1[j] * static_cast<double>(loop_ub);
      t = d;
      d1 += transforms[1].Adgbi.Link2[j] * static_cast<double>(loop_ub);
      R_0_B_tmp_tmp = d;
      R_0_B_tmp = d1;
      d2 += transforms[1].Adgbi.Link3[j] * static_cast<double>(loop_ub);
      b_R_0_B_tmp = d;
      b_R_0_B_tmp_tmp = d1;
      c_R_0_B_tmp_tmp = d2;
      S_0_B_tmp += transforms[1].Adgbi.Link4[j] * static_cast<double>(loop_ub);
      d_R_0_B_tmp_tmp +=
          transforms[1].Adgbi.EE[j] * static_cast<double>(loop_ub);
    }
    Ji[1].EE[i + 18] = d_R_0_B_tmp_tmp;
    Ji[1].Link5[i + 18] = S_0_B_tmp;
    Ji[1].Link5[i + 12] = c_R_0_B_tmp_tmp;
    Ji[1].Link5[i + 6] = b_R_0_B_tmp_tmp;
    Ji[1].Link5[i] = b_R_0_B_tmp;
    Ji[1].Link4[i + 12] = d2;
    Ji[1].Link4[i + 6] = R_0_B_tmp;
    Ji[1].Link4[i] = R_0_B_tmp_tmp;
    Ji[1].Link3[i + 6] = d1;
    Ji[1].Link3[i] = t;
    Ji[1].Link2[i] = d;
  }
  std::memset(&Ji[1].Link1[0], 0, 24U * sizeof(double));
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[0].Adgbi_inv.Link1[i + 6 * j] * 0.0;
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link1[j] = transforms[0].Adgbi_inv.Link1[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link1[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[0].Adgbi_inv.Link2[i + 6 * j] *
             Ji[0].Link2[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link2[j] = transforms[0].Adgbi_inv.Link2[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link2[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[0].Adgbi_inv.Link3[i + 6 * j] *
             Ji[0].Link3[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link3[j] = transforms[0].Adgbi_inv.Link3[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link3[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[0].Adgbi_inv.Link4[i + 6 * j] *
             Ji[0].Link4[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link4[j] = transforms[0].Adgbi_inv.Link4[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link4[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[0].Adgbi_inv.Link5[i + 6 * j] *
             Ji[0].Link5[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link5[j] = transforms[0].Adgbi_inv.Link5[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link5[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[0].Adgbi_inv.EE[i + 6 * j] * Ji[0].EE[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].EE[j] = transforms[0].Adgbi_inv.EE[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].EE[36]);
  for (i = 0; i < 60; i++) {
    Jbs[0].Link1[i] = Jbs[1].Link1[i];
    Jbs[0].Link2[i] = Jbs[1].Link2[i];
    Jbs[0].Link3[i] = Jbs[1].Link3[i];
    Jbs[0].Link4[i] = Jbs[1].Link4[i];
    Jbs[0].Link5[i] = Jbs[1].Link5[i];
    Jbs[0].EE[i] = Jbs[1].EE[i];
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[1].Adgbi_inv.Link1[i + 6 * j] * 0.0;
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link1[j] = transforms[1].Adgbi_inv.Link1[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link1[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[1].Adgbi_inv.Link2[i + 6 * j] *
             Ji[1].Link2[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link2[j] = transforms[1].Adgbi_inv.Link2[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link2[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[1].Adgbi_inv.Link3[i + 6 * j] *
             Ji[1].Link3[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link3[j] = transforms[1].Adgbi_inv.Link3[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link3[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[1].Adgbi_inv.Link4[i + 6 * j] *
             Ji[1].Link4[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link4[j] = transforms[1].Adgbi_inv.Link4[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link4[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[1].Adgbi_inv.Link5[i + 6 * j] *
             Ji[1].Link5[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].Link5[j] = transforms[1].Adgbi_inv.Link5[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].Link5[36]);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 4; aoffset++) {
      t = 0.0;
      for (j = 0; j < 6; j++) {
        t += transforms[1].Adgbi_inv.EE[i + 6 * j] * Ji[1].EE[j + 6 * aoffset];
      }
      b_transforms[i + 6 * aoffset] = t;
    }
    for (aoffset = 0; aoffset < 6; aoffset++) {
      j = aoffset + 6 * i;
      Jbs[1].EE[j] = transforms[1].Adgbi_inv.EE[j];
    }
  }
  std::copy(&b_transforms[0], &b_transforms[24], &Jbs[1].EE[36]);
  Jacobians[0].Jb = Jbs[0];
  Jacobians[0].Ji = Ji[0];
  Jacobians[1].Jb = Jbs[1];
  Jacobians[1].Ji = Ji[1];
  for (i = 0; i < 36; i++) {
    b_I[i] = 0;
  }
  for (k = 0; k < 6; k++) {
    b_I[k + 6 * k] = 1;
  }
  Jvehicle.set_size(6, static_cast<int>(params->NumDoFs - 6.0) + 6);
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jvehicle[aoffset + 6 * i] = b_I[aoffset + 6 * i];
    }
  }
  loop_ub = static_cast<int>(params->NumDoFs - 6.0);
  for (i = 0; i < loop_ub; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jvehicle[aoffset + 6 * (i + 6)] = 0.0;
    }
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  loop_ub_tmp = 6 * static_cast<int>(params->NumDoFs);
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[0].Jb.Link2[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 6)] = Jacobians[0].Jb.Link2[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Mass;
  b_d[4] = params->Mass;
  b_d[8] = params->Mass;
  v[0] = params->Arms.Arm1.Links.Link2.Mass;
  v[1] = params->Arms.Arm1.Links.Link2.Mass;
  v[2] = params->Arms.Arm1.Links.Link2.Mass;
  std::memset(&c_d[0], 0, 9U * sizeof(double));
  for (j = 0; j < 3; j++) {
    c_d[j + 3 * j] = v[j];
    d_d[6 * j] = b_d[3 * j] + params->AddedMassMatrix[6 * j];
    d_tmp = 6 * (j + 3);
    d_d[d_tmp] = params->AddedMassMatrix[d_tmp];
    aoffset = 6 * j + 3;
    d_d[aoffset] = params->AddedMassMatrix[aoffset];
    d_d[d_tmp + 3] =
        params->Inertia[3 * j] + params->AddedMassMatrix[d_tmp + 3];
    aoffset = 6 * j + 1;
    k = 3 * j + 1;
    d_d[aoffset] = b_d[k] + params->AddedMassMatrix[aoffset];
    d_d[d_tmp + 1] = params->AddedMassMatrix[d_tmp + 1];
    aoffset = 6 * j + 4;
    d_d[aoffset] = params->AddedMassMatrix[aoffset];
    d_d[d_tmp + 4] = params->Inertia[k] + params->AddedMassMatrix[d_tmp + 4];
    aoffset = 6 * j + 2;
    k = 3 * j + 2;
    d_d[aoffset] = b_d[k] + params->AddedMassMatrix[aoffset];
    d_d[d_tmp + 2] = params->AddedMassMatrix[d_tmp + 2];
    aoffset = 6 * j + 5;
    d_d[aoffset] = params->AddedMassMatrix[aoffset];
    d_d[d_tmp + 5] = params->Inertia[k] + params->AddedMassMatrix[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jvehicle, d_d, r);
  coder::internal::blas::mtimes(r, Jvehicle, M);
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = c_d[3 * i] + params->Arms.Arm1.Links.Link2.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm1.Links.Link2.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm1.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm1.Links.Link2.InertiaTensor[3 * i] +
                     params->Arms.Arm1.Links.Link2.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = c_d[k] + params->Arms.Arm1.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm1.Links.Link2.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm1.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm1.Links.Link2.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link2.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = c_d[k] + params->Arms.Arm1.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm1.Links.Link2.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm1.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm1.Links.Link2.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link2.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[0].Jb.Link3[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 6)] = Jacobians[0].Jb.Link3[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Arms.Arm1.Links.Link3.Mass;
  b_d[4] = params->Arms.Arm1.Links.Link3.Mass;
  b_d[8] = params->Arms.Arm1.Links.Link3.Mass;
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = b_d[3 * i] + params->Arms.Arm1.Links.Link3.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm1.Links.Link3.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm1.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm1.Links.Link3.InertiaTensor[3 * i] +
                     params->Arms.Arm1.Links.Link3.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = b_d[k] + params->Arms.Arm1.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm1.Links.Link3.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm1.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm1.Links.Link3.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link3.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = b_d[k] + params->Arms.Arm1.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm1.Links.Link3.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm1.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm1.Links.Link3.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link3.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[0].Jb.Link4[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 6)] = Jacobians[0].Jb.Link4[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Arms.Arm1.Links.Link4.Mass;
  b_d[4] = params->Arms.Arm1.Links.Link4.Mass;
  b_d[8] = params->Arms.Arm1.Links.Link4.Mass;
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = b_d[3 * i] + params->Arms.Arm1.Links.Link4.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm1.Links.Link4.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm1.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm1.Links.Link4.InertiaTensor[3 * i] +
                     params->Arms.Arm1.Links.Link4.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = b_d[k] + params->Arms.Arm1.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm1.Links.Link4.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm1.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm1.Links.Link4.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link4.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = b_d[k] + params->Arms.Arm1.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm1.Links.Link4.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm1.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm1.Links.Link4.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link4.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[0].Jb.Link5[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 6)] = Jacobians[0].Jb.Link5[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Arms.Arm1.Links.Link5.Mass;
  b_d[4] = params->Arms.Arm1.Links.Link5.Mass;
  b_d[8] = params->Arms.Arm1.Links.Link5.Mass;
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = b_d[3 * i] + params->Arms.Arm1.Links.Link5.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm1.Links.Link5.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm1.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm1.Links.Link5.InertiaTensor[3 * i] +
                     params->Arms.Arm1.Links.Link5.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = b_d[k] + params->Arms.Arm1.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm1.Links.Link5.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm1.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm1.Links.Link5.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link5.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = b_d[k] + params->Arms.Arm1.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm1.Links.Link5.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm1.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm1.Links.Link5.InertiaTensor[k] +
                     params->Arms.Arm1.Links.Link5.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[1].Jb.Link2[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 10)] =
          Jacobians[1].Jb.Link2[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Arms.Arm2.Links.Link2.Mass;
  b_d[4] = params->Arms.Arm2.Links.Link2.Mass;
  b_d[8] = params->Arms.Arm2.Links.Link2.Mass;
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = b_d[3 * i] + params->Arms.Arm2.Links.Link2.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm2.Links.Link2.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm2.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm2.Links.Link2.InertiaTensor[3 * i] +
                     params->Arms.Arm2.Links.Link2.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm2.Links.Link2.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm2.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm2.Links.Link2.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link2.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm2.Links.Link2.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm2.Links.Link2.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm2.Links.Link2.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link2.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[1].Jb.Link3[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 10)] =
          Jacobians[1].Jb.Link3[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Arms.Arm2.Links.Link3.Mass;
  b_d[4] = params->Arms.Arm2.Links.Link3.Mass;
  b_d[8] = params->Arms.Arm2.Links.Link3.Mass;
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = b_d[3 * i] + params->Arms.Arm2.Links.Link3.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm2.Links.Link3.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm2.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm2.Links.Link3.InertiaTensor[3 * i] +
                     params->Arms.Arm2.Links.Link3.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm2.Links.Link3.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm2.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm2.Links.Link3.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link3.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm2.Links.Link3.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm2.Links.Link3.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm2.Links.Link3.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link3.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[1].Jb.Link4[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 10)] =
          Jacobians[1].Jb.Link4[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Arms.Arm2.Links.Link4.Mass;
  b_d[4] = params->Arms.Arm2.Links.Link4.Mass;
  b_d[8] = params->Arms.Arm2.Links.Link4.Mass;
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = b_d[3 * i] + params->Arms.Arm2.Links.Link4.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm2.Links.Link4.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm2.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm2.Links.Link4.InertiaTensor[3 * i] +
                     params->Arms.Arm2.Links.Link4.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm2.Links.Link4.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm2.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm2.Links.Link4.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link4.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm2.Links.Link4.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm2.Links.Link4.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm2.Links.Link4.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link4.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  Jbi.set_size(6, static_cast<int>(params->NumDoFs));
  for (i = 0; i < loop_ub_tmp; i++) {
    Jbi[i] = 0.0;
  }
  for (i = 0; i < 6; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * i] = Jacobians[1].Jb.Link5[aoffset + 6 * i];
    }
  }
  for (i = 0; i < 4; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      Jbi[aoffset + 6 * (i + 10)] =
          Jacobians[1].Jb.Link5[aoffset + 6 * (i + 6)];
    }
  }
  std::memset(&b_d[0], 0, 9U * sizeof(double));
  b_d[0] = params->Arms.Arm2.Links.Link5.Mass;
  b_d[4] = params->Arms.Arm2.Links.Link5.Mass;
  b_d[8] = params->Arms.Arm2.Links.Link5.Mass;
  for (i = 0; i < 3; i++) {
    d_d[6 * i] = b_d[3 * i] + params->Arms.Arm2.Links.Link5.AddedMass[6 * i];
    d_tmp = 6 * (i + 3);
    d_d[d_tmp] = params->Arms.Arm2.Links.Link5.AddedMass[d_tmp];
    aoffset = 6 * i + 3;
    d_d[aoffset] = params->Arms.Arm2.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 3] = params->Arms.Arm2.Links.Link5.InertiaTensor[3 * i] +
                     params->Arms.Arm2.Links.Link5.AddedMass[d_tmp + 3];
    aoffset = 6 * i + 1;
    k = 3 * i + 1;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 1] = params->Arms.Arm2.Links.Link5.AddedMass[d_tmp + 1];
    aoffset = 6 * i + 4;
    d_d[aoffset] = params->Arms.Arm2.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 4] = params->Arms.Arm2.Links.Link5.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link5.AddedMass[d_tmp + 4];
    aoffset = 6 * i + 2;
    k = 3 * i + 2;
    d_d[aoffset] = b_d[k] + params->Arms.Arm2.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 2] = params->Arms.Arm2.Links.Link5.AddedMass[d_tmp + 2];
    aoffset = 6 * i + 5;
    d_d[aoffset] = params->Arms.Arm2.Links.Link5.AddedMass[aoffset];
    d_d[d_tmp + 5] = params->Arms.Arm2.Links.Link5.InertiaTensor[k] +
                     params->Arms.Arm2.Links.Link5.AddedMass[d_tmp + 5];
  }
  coder::internal::blas::mtimes(Jbi, d_d, r);
  coder::internal::blas::mtimes(r, Jbi, C);
  if ((M.size(0) == C.size(0)) && (M.size(1) == C.size(1))) {
    loop_ub = M.size(0) * M.size(1);
    for (i = 0; i < loop_ub; i++) {
      M[i] = M[i] + C[i];
    }
  } else {
    plus(M, C);
  }
  calculateCoriolisMatrix(
      params->Mass, params->Inertia, params->AddedMassMatrix, params->NumDoFs,
      params->Arms.Arm1.Links.Link2.Mass,
      params->Arms.Arm1.Links.Link2.InertiaTensor,
      params->Arms.Arm1.Links.Link2.AddedMass,
      params->Arms.Arm1.Links.Link3.Mass,
      params->Arms.Arm1.Links.Link3.InertiaTensor,
      params->Arms.Arm1.Links.Link3.AddedMass,
      params->Arms.Arm1.Links.Link4.Mass,
      params->Arms.Arm1.Links.Link4.InertiaTensor,
      params->Arms.Arm1.Links.Link4.AddedMass,
      params->Arms.Arm1.Links.Link5.Mass,
      params->Arms.Arm1.Links.Link5.InertiaTensor,
      params->Arms.Arm1.Links.Link5.AddedMass, params->Arms.Arm2.Links.Link2,
      params->Arms.Arm2.Links.Link3, params->Arms.Arm2.Links.Link4,
      params->Arms.Arm2.Links.Link5, zeta, Jacobians, transforms, C);
  calculateHydrodynamicDamping(
      params->CenterOfMass, params->LinearDamping, params->QuadraticDamping,
      params->NumDoFs, params->Arms.Arm1.Links.Link2.CenterOfMass,
      params->Arms.Arm1.Links.Link2.LinearDamping,
      params->Arms.Arm1.Links.Link2.QuadraticDamping,
      params->Arms.Arm1.Links.Link3.CenterOfMass,
      params->Arms.Arm1.Links.Link3.LinearDamping,
      params->Arms.Arm1.Links.Link3.QuadraticDamping,
      params->Arms.Arm1.Links.Link4.CenterOfMass,
      params->Arms.Arm1.Links.Link4.LinearDamping,
      params->Arms.Arm1.Links.Link4.QuadraticDamping,
      params->Arms.Arm1.Links.Link5.CenterOfMass,
      params->Arms.Arm1.Links.Link5.LinearDamping,
      params->Arms.Arm1.Links.Link5.QuadraticDamping,
      params->Arms.Arm2.Links.Link2, params->Arms.Arm2.Links.Link3,
      params->Arms.Arm2.Links.Link4, params->Arms.Arm2.Links.Link5, zeta,
      Jacobians, D);
  calculatePersistentForces(
      params->Mass, params->CenterOfMass, params->Volume,
      params->CenterOfBuoyancy, params->NumDoFs, params->g, params->rho,
      params->Arms.Arm1.Links.Link2.Mass,
      params->Arms.Arm1.Links.Link2.CenterOfMass,
      params->Arms.Arm1.Links.Link2.Volume,
      params->Arms.Arm1.Links.Link2.CenterOfBuoyancy,
      params->Arms.Arm1.Links.Link3.Mass,
      params->Arms.Arm1.Links.Link3.CenterOfMass,
      params->Arms.Arm1.Links.Link3.Volume,
      params->Arms.Arm1.Links.Link3.CenterOfBuoyancy,
      params->Arms.Arm1.Links.Link4, params->Arms.Arm1.Links.Link5,
      params->Arms.Arm2.Links.Link2, params->Arms.Arm2.Links.Link3,
      params->Arms.Arm2.Links.Link4, params->Arms.Arm2.Links.Link5, ksi,
      Jacobians, transforms, N);
  t = std::cos(ksi[5]);
  R_0_B_tmp_tmp = std::cos(ksi[3]);
  R_0_B_tmp = std::sin(ksi[4]);
  b_R_0_B_tmp = std::sin(ksi[5]);
  b_R_0_B_tmp_tmp = std::sin(ksi[3]);
  c_R_0_B_tmp_tmp = std::cos(ksi[4]);
  S_0_B_tmp = std::tan(ksi[4]);
  // Jw = calculate_workspace_Jacobian(params, ksi, Kinematics);
  c_R_0_B_tmp[0] = t * c_R_0_B_tmp_tmp;
  c_R_0_B_tmp[14] =
      t * R_0_B_tmp * b_R_0_B_tmp_tmp - b_R_0_B_tmp * R_0_B_tmp_tmp;
  d_R_0_B_tmp_tmp = t * R_0_B_tmp_tmp;
  c_R_0_B_tmp[28] = d_R_0_B_tmp_tmp * R_0_B_tmp + b_R_0_B_tmp * b_R_0_B_tmp_tmp;
  c_R_0_B_tmp[1] = b_R_0_B_tmp * c_R_0_B_tmp_tmp;
  c_R_0_B_tmp[15] = b_R_0_B_tmp_tmp * R_0_B_tmp * b_R_0_B_tmp + d_R_0_B_tmp_tmp;
  c_R_0_B_tmp[29] =
      R_0_B_tmp * b_R_0_B_tmp * R_0_B_tmp_tmp - t * b_R_0_B_tmp_tmp;
  c_R_0_B_tmp[2] = -R_0_B_tmp;
  c_R_0_B_tmp[16] = c_R_0_B_tmp_tmp * b_R_0_B_tmp_tmp;
  c_R_0_B_tmp[30] = c_R_0_B_tmp_tmp * R_0_B_tmp_tmp;
  for (i = 0; i < 3; i++) {
    j = 14 * (i + 3);
    c_R_0_B_tmp[j] = 0.0;
    c_R_0_B_tmp[j + 1] = 0.0;
    c_R_0_B_tmp[j + 2] = 0.0;
  }
  for (i = 0; i < 8; i++) {
    j = 14 * (i + 6);
    c_R_0_B_tmp[j] = 0.0;
    c_R_0_B_tmp[j + 1] = 0.0;
    c_R_0_B_tmp[j + 2] = 0.0;
  }
  for (i = 0; i < 3; i++) {
    c_R_0_B_tmp[14 * i + 3] = 0.0;
    c_R_0_B_tmp[14 * i + 4] = 0.0;
    c_R_0_B_tmp[14 * i + 5] = 0.0;
  }
  c_R_0_B_tmp[45] = 1.0;
  c_R_0_B_tmp[59] = b_R_0_B_tmp_tmp * S_0_B_tmp;
  c_R_0_B_tmp[73] = R_0_B_tmp_tmp * S_0_B_tmp;
  c_R_0_B_tmp[46] = 0.0;
  c_R_0_B_tmp[60] = R_0_B_tmp_tmp;
  c_R_0_B_tmp[74] = -b_R_0_B_tmp_tmp;
  c_R_0_B_tmp[47] = 0.0;
  c_R_0_B_tmp[61] = b_R_0_B_tmp_tmp / c_R_0_B_tmp_tmp;
  c_R_0_B_tmp[75] = R_0_B_tmp_tmp / c_R_0_B_tmp_tmp;
  for (i = 0; i < 8; i++) {
    j = 14 * (i + 6);
    c_R_0_B_tmp[j + 3] = 0.0;
    c_R_0_B_tmp[j + 4] = 0.0;
    c_R_0_B_tmp[j + 5] = 0.0;
  }
  for (i = 0; i < 14; i++) {
    for (aoffset = 0; aoffset < 8; aoffset++) {
      c_R_0_B_tmp[(aoffset + 14 * i) + 6] = b_iv[aoffset + (i << 3)];
    }
  }
  for (i = 0; i < 14; i++) {
    t = 0.0;
    for (aoffset = 0; aoffset < 14; aoffset++) {
      t += c_R_0_B_tmp[i + 14 * aoffset] * zeta[aoffset];
    }
    dksi_dt[i] = t;
  }
  if ((C.size(0) == D.size(0)) && (C.size(1) == D.size(1))) {
    loop_ub = C.size(0) * C.size(1);
    for (i = 0; i < loop_ub; i++) {
      C[i] = -(C[i] + D[i]);
    }
  } else {
    binary_expand_op(C, D);
  }
  loop_ub = C.size(0) - 1;
  j = C.size(1);
  b_C.set_size(C.size(0));
  for (d_tmp = 0; d_tmp <= loop_ub; d_tmp++) {
    b_C[d_tmp] = 0.0;
  }
  for (k = 0; k < j; k++) {
    aoffset = k * C.size(0);
    for (d_tmp = 0; d_tmp <= loop_ub; d_tmp++) {
      b_C[d_tmp] = b_C[d_tmp] + C[aoffset + d_tmp] * zeta[k];
    }
  }
  if (params->NumDoFs - 6.0 < 0.0) {
    t = 0.0;
    j = 0;
  } else {
    t = params->NumDoFs - 6.0;
    j = static_cast<int>(params->NumDoFs - 6.0);
  }
  C.set_size(static_cast<int>(t), static_cast<int>(t));
  loop_ub = static_cast<int>(t) * static_cast<int>(t);
  for (i = 0; i < loop_ub; i++) {
    C[i] = 0.0;
  }
  if (static_cast<int>(t) > 0) {
    for (k = 0; k < j; k++) {
      C[k + C.size(0) * k] = 1.0;
    }
  }
  D.set_size(C.size(0) + 6, C.size(1) + 7);
  loop_ub_tmp = (C.size(0) + 6) * (C.size(1) + 7);
  for (i = 0; i < loop_ub_tmp; i++) {
    D[i] = 0.0;
  }
  for (i = 0; i < 7; i++) {
    for (aoffset = 0; aoffset < 6; aoffset++) {
      D[aoffset + D.size(0) * i] =
          params->ThrusterAllocationMatrix[aoffset + 6 * i];
    }
  }
  if ((C.size(0) > 0) && (C.size(1) > 0)) {
    loop_ub = C.size(1);
    j = C.size(0);
    for (i = 0; i < loop_ub; i++) {
      for (aoffset = 0; aoffset < j; aoffset++) {
        D[(aoffset + D.size(0) * (i + 7)) + 6] = C[aoffset + C.size(0) * i];
      }
    }
  }
  loop_ub = D.size(0) - 1;
  j = D.size(1);
  c_C.set_size(D.size(0));
  for (d_tmp = 0; d_tmp <= loop_ub; d_tmp++) {
    c_C[d_tmp] = 0.0;
  }
  for (k = 0; k < j; k++) {
    aoffset = k * D.size(0);
    for (d_tmp = 0; d_tmp <= loop_ub; d_tmp++) {
      c_C[d_tmp] = c_C[d_tmp] + D[aoffset + d_tmp] * control_input[k];
    }
  }
  if (b_C.size(0) == 1) {
    i = N.size(0);
  } else {
    i = b_C.size(0);
  }
  if ((M.size(0) == 14) && (M.size(1) == 14) && (b_C.size(0) == N.size(0)) &&
      (i == c_C.size(0))) {
    for (i = 0; i < 196; i++) {
      c_R_0_B_tmp[i] = M[i];
    }
    loop_ub = b_C.size(0);
    for (i = 0; i < loop_ub; i++) {
      b_C[i] = (b_C[i] - N[i]) + c_C[i];
    }
    dzeta_dt_size[0] = coder::mldivide(c_R_0_B_tmp, b_C, dzeta_dt_data);
  } else {
    dzeta_dt_size[0] = binary_expand_op(dzeta_dt_data, M, b_C, N, c_C);
  }
}

//
// File trailer for forward_dynamics.cpp
//
// [EOF]
//
