//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateArmTransforms.cpp
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

// Include Files
#include "calculateArmTransforms.h"
#include <algorithm>
#include <cmath>

// Function Definitions
//
// Calculate transformations for each link in the arm
//
// Arguments    : const double params_Arms_Arm2_TransformVehicleToArmBase[16]
//                const double params_Arms_Arm2_LastLinkToEE[16]
//                const double params_Arms_Arm2_DHParameters_d[5]
//                const double params_Arms_Arm2_DHParameters_theta[5]
//                const double params_Arms_Arm2_DHParameters_a[5]
//                const double params_Arms_Arm2_DHParameters_alpha[5]
//                const double ksi[14]
//                const double T_global[16]
//                double arm_transforms_Link1[16]
//                double arm_transforms_Link2[16]
//                double arm_transforms_Link3[16]
//                double arm_transforms_Link4[16]
//                double arm_transforms_Link5[16]
//                double arm_transforms_EE[16]
// Return Type  : void
//
void b_calculateArmTransforms(
    const double params_Arms_Arm2_TransformVehicleToArmBase[16],
    const double params_Arms_Arm2_LastLinkToEE[16],
    const double params_Arms_Arm2_DHParameters_d[5],
    const double params_Arms_Arm2_DHParameters_theta[5],
    const double params_Arms_Arm2_DHParameters_a[5],
    const double params_Arms_Arm2_DHParameters_alpha[5], const double ksi[14],
    const double T_global[16], double arm_transforms_Link1[16],
    double arm_transforms_Link2[16], double arm_transforms_Link3[16],
    double arm_transforms_Link4[16], double arm_transforms_Link5[16],
    double arm_transforms_EE[16])
{
  double b_arm_transforms_Link5[16];
  double d_T_tmp[16];
  double T_tmp;
  double b_T_tmp;
  double c_T_tmp;
  double dh_row_idx_1;
  int i2;
  //  Start with the base transform
  // jointnames = fieldnames(params.Arms.(armname).Joints);
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = T_global[i];
    T_tmp = T_global[i + 4];
    b_T_tmp = T_global[i + 8];
    c_T_tmp = T_global[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * params_Arms_Arm2_TransformVehicleToArmBase[i2] +
            T_tmp * params_Arms_Arm2_TransformVehicleToArmBase[i2 + 1]) +
           b_T_tmp * params_Arms_Arm2_TransformVehicleToArmBase[i2 + 2]) +
          c_T_tmp * params_Arms_Arm2_TransformVehicleToArmBase[i2 + 3];
    }
  }
  std::copy(&arm_transforms_Link5[0], &arm_transforms_Link5[16],
            &arm_transforms_Link1[0]);
  dh_row_idx_1 = params_Arms_Arm2_DHParameters_theta[0] + ksi[10];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm2_DHParameters_alpha[0]);
  b_T_tmp = std::sin(params_Arms_Arm2_DHParameters_alpha[0]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm2_DHParameters_a[0] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm2_DHParameters_a[0] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm2_DHParameters_d[0];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link2[0]);
  dh_row_idx_1 = params_Arms_Arm2_DHParameters_theta[1] + ksi[11];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm2_DHParameters_alpha[1]);
  b_T_tmp = std::sin(params_Arms_Arm2_DHParameters_alpha[1]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm2_DHParameters_a[1] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm2_DHParameters_a[1] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm2_DHParameters_d[1];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link3[0]);
  dh_row_idx_1 = params_Arms_Arm2_DHParameters_theta[2] + ksi[12];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm2_DHParameters_alpha[2]);
  b_T_tmp = std::sin(params_Arms_Arm2_DHParameters_alpha[2]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm2_DHParameters_a[2] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm2_DHParameters_a[2] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm2_DHParameters_d[2];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link4[0]);
  dh_row_idx_1 = params_Arms_Arm2_DHParameters_theta[3] + ksi[13];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm2_DHParameters_alpha[3]);
  b_T_tmp = std::sin(params_Arms_Arm2_DHParameters_alpha[3]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm2_DHParameters_a[3] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm2_DHParameters_a[3] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm2_DHParameters_d[3];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      arm_transforms_EE[i + i2] =
          ((dh_row_idx_1 * params_Arms_Arm2_LastLinkToEE[i2] +
            T_tmp * params_Arms_Arm2_LastLinkToEE[i2 + 1]) +
           b_T_tmp * params_Arms_Arm2_LastLinkToEE[i2 + 2]) +
          c_T_tmp * params_Arms_Arm2_LastLinkToEE[i2 + 3];
    }
  }
}

//
// Calculate transformations for each link in the arm
//
// Arguments    : const double params_Arms_Arm1_TransformVehicleToArmBase[16]
//                const double params_Arms_Arm1_LastLinkToEE[16]
//                const double params_Arms_Arm1_DHParameters_d[5]
//                const double params_Arms_Arm1_DHParameters_theta[5]
//                const double params_Arms_Arm1_DHParameters_a[5]
//                const double params_Arms_Arm1_DHParameters_alpha[5]
//                const double ksi[14]
//                const double T_global[16]
//                double arm_transforms_Link1[16]
//                double arm_transforms_Link2[16]
//                double arm_transforms_Link3[16]
//                double arm_transforms_Link4[16]
//                double arm_transforms_Link5[16]
//                double arm_transforms_EE[16]
// Return Type  : void
//
void calculateArmTransforms(
    const double params_Arms_Arm1_TransformVehicleToArmBase[16],
    const double params_Arms_Arm1_LastLinkToEE[16],
    const double params_Arms_Arm1_DHParameters_d[5],
    const double params_Arms_Arm1_DHParameters_theta[5],
    const double params_Arms_Arm1_DHParameters_a[5],
    const double params_Arms_Arm1_DHParameters_alpha[5], const double ksi[14],
    const double T_global[16], double arm_transforms_Link1[16],
    double arm_transforms_Link2[16], double arm_transforms_Link3[16],
    double arm_transforms_Link4[16], double arm_transforms_Link5[16],
    double arm_transforms_EE[16])
{
  double b_arm_transforms_Link5[16];
  double d_T_tmp[16];
  double T_tmp;
  double b_T_tmp;
  double c_T_tmp;
  double dh_row_idx_1;
  int i2;
  //  Start with the base transform
  // jointnames = fieldnames(params.Arms.(armname).Joints);
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = T_global[i];
    T_tmp = T_global[i + 4];
    b_T_tmp = T_global[i + 8];
    c_T_tmp = T_global[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * params_Arms_Arm1_TransformVehicleToArmBase[i2] +
            T_tmp * params_Arms_Arm1_TransformVehicleToArmBase[i2 + 1]) +
           b_T_tmp * params_Arms_Arm1_TransformVehicleToArmBase[i2 + 2]) +
          c_T_tmp * params_Arms_Arm1_TransformVehicleToArmBase[i2 + 3];
    }
  }
  std::copy(&arm_transforms_Link5[0], &arm_transforms_Link5[16],
            &arm_transforms_Link1[0]);
  dh_row_idx_1 = params_Arms_Arm1_DHParameters_theta[0] + ksi[6];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm1_DHParameters_alpha[0]);
  b_T_tmp = std::sin(params_Arms_Arm1_DHParameters_alpha[0]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm1_DHParameters_a[0] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm1_DHParameters_a[0] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm1_DHParameters_d[0];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link2[0]);
  dh_row_idx_1 = params_Arms_Arm1_DHParameters_theta[1] + ksi[7];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm1_DHParameters_alpha[1]);
  b_T_tmp = std::sin(params_Arms_Arm1_DHParameters_alpha[1]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm1_DHParameters_a[1] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm1_DHParameters_a[1] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm1_DHParameters_d[1];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link3[0]);
  dh_row_idx_1 = params_Arms_Arm1_DHParameters_theta[2] + ksi[8];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm1_DHParameters_alpha[2]);
  b_T_tmp = std::sin(params_Arms_Arm1_DHParameters_alpha[2]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm1_DHParameters_a[2] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm1_DHParameters_a[2] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm1_DHParameters_d[2];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link4[0]);
  dh_row_idx_1 = params_Arms_Arm1_DHParameters_theta[3] + ksi[9];
  //  Extract parameters from the input row
  //  Define the transformation matrix using the DH parameters
  c_T_tmp = std::sin(dh_row_idx_1);
  dh_row_idx_1 = std::cos(dh_row_idx_1);
  T_tmp = std::cos(params_Arms_Arm1_DHParameters_alpha[3]);
  b_T_tmp = std::sin(params_Arms_Arm1_DHParameters_alpha[3]);
  d_T_tmp[0] = dh_row_idx_1;
  d_T_tmp[4] = -c_T_tmp * T_tmp;
  d_T_tmp[8] = c_T_tmp * b_T_tmp;
  d_T_tmp[12] = params_Arms_Arm1_DHParameters_a[3] * dh_row_idx_1;
  d_T_tmp[1] = c_T_tmp;
  d_T_tmp[5] = dh_row_idx_1 * T_tmp;
  d_T_tmp[9] = -dh_row_idx_1 * b_T_tmp;
  d_T_tmp[13] = params_Arms_Arm1_DHParameters_a[3] * c_T_tmp;
  d_T_tmp[2] = 0.0;
  d_T_tmp[6] = b_T_tmp;
  d_T_tmp[10] = T_tmp;
  d_T_tmp[14] = params_Arms_Arm1_DHParameters_d[3];
  d_T_tmp[3] = 0.0;
  d_T_tmp[7] = 0.0;
  d_T_tmp[11] = 0.0;
  d_T_tmp[15] = 1.0;
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      b_arm_transforms_Link5[i + i2] =
          ((dh_row_idx_1 * d_T_tmp[i2] + T_tmp * d_T_tmp[i2 + 1]) +
           b_T_tmp * d_T_tmp[i2 + 2]) +
          c_T_tmp * d_T_tmp[i2 + 3];
    }
  }
  std::copy(&b_arm_transforms_Link5[0], &b_arm_transforms_Link5[16],
            &arm_transforms_Link5[0]);
  // axang2tform([0 0 1 ksi(k)]) *
  // params.Arms.(armname).Joints.(jointnames{i-1}).TransformParentToChild; %its
  // the same
  for (int i{0}; i < 4; i++) {
    dh_row_idx_1 = arm_transforms_Link5[i];
    T_tmp = arm_transforms_Link5[i + 4];
    b_T_tmp = arm_transforms_Link5[i + 8];
    c_T_tmp = arm_transforms_Link5[i + 12];
    for (int i1{0}; i1 < 4; i1++) {
      i2 = i1 << 2;
      arm_transforms_EE[i + i2] =
          ((dh_row_idx_1 * params_Arms_Arm1_LastLinkToEE[i2] +
            T_tmp * params_Arms_Arm1_LastLinkToEE[i2 + 1]) +
           b_T_tmp * params_Arms_Arm1_LastLinkToEE[i2 + 2]) +
          c_T_tmp * params_Arms_Arm1_LastLinkToEE[i2 + 3];
    }
  }
}

//
// File trailer for calculateArmTransforms.cpp
//
// [EOF]
//
