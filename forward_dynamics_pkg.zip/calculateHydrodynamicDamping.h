//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculateHydrodynamicDamping.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef CALCULATEHYDRODYNAMICDAMPING_H
#define CALCULATEHYDRODYNAMICDAMPING_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct struct5_T;

struct d_struct_T;

// Function Declarations
void calculateHydrodynamicDamping(
    const double params_CenterOfMass[3], const double params_LinearDamping[36],
    const double params_QuadraticDamping[36], double params_NumDoFs,
    const double params_Arms_Arm1_Links_Link2_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link2_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link2_QuadraticDamping[36],
    const double params_Arms_Arm1_Links_Link3_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link3_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link3_QuadraticDamping[36],
    const double params_Arms_Arm1_Links_Link4_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link4_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link4_QuadraticDamping[36],
    const double params_Arms_Arm1_Links_Link5_CenterOfMass[3],
    const double params_Arms_Arm1_Links_Link5_LinearDamping[36],
    const double params_Arms_Arm1_Links_Link5_QuadraticDamping[36],
    const struct5_T &params_Arms_Arm2_Links_Link2,
    const struct5_T &params_Arms_Arm2_Links_Link3,
    const struct5_T &params_Arms_Arm2_Links_Link4,
    const struct5_T &params_Arms_Arm2_Links_Link5, const double zeta[14],
    const d_struct_T Kinematics_Jacobians[2], coder::array<double, 2U> &D);

#endif
//
// File trailer for calculateHydrodynamicDamping.h
//
// [EOF]
//
