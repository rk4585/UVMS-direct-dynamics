//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calculatePersistentForces.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef CALCULATEPERSISTENTFORCES_H
#define CALCULATEPERSISTENTFORCES_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct struct5_T;

struct d_struct_T;

struct h_struct_T;

// Function Declarations
void calculatePersistentForces(
    double params_Mass, const double params_CenterOfMass[3],
    double params_Volume, const double params_CenterOfBuoyancy[3],
    double params_NumDoFs, double params_g, double params_rho,
    double params_Arms_Arm1_Links_Link2_Mass,
    const double params_Arms_Arm1_Links_Link2_CenterOfMass[3],
    double params_Arms_Arm1_Links_Link2_Volume,
    const double params_Arms_Arm1_Links_Link2_CenterOfBuoyancy[3],
    double params_Arms_Arm1_Links_Link3_Mass,
    const double params_Arms_Arm1_Links_Link3_CenterOfMass[3],
    double params_Arms_Arm1_Links_Link3_Volume,
    const double params_Arms_Arm1_Links_Link3_CenterOfBuoyancy[3],
    const struct5_T &params_Arms_Arm1_Links_Link4,
    const struct5_T &params_Arms_Arm1_Links_Link5,
    const struct5_T &params_Arms_Arm2_Links_Link2,
    const struct5_T &params_Arms_Arm2_Links_Link3,
    const struct5_T &params_Arms_Arm2_Links_Link4,
    const struct5_T &params_Arms_Arm2_Links_Link5, const double ksi[14],
    const d_struct_T Kinematics_Jacobians[2],
    const h_struct_T Kinematics_Transforms[2], coder::array<double, 1U> &N_p);

#endif
//
// File trailer for calculatePersistentForces.h
//
// [EOF]
//
