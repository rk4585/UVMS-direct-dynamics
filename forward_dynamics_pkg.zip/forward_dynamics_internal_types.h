//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: forward_dynamics_internal_types.h
//
// MATLAB Coder version            : 5.6
// C/C++ source code generated on  : 04-Oct-2024 17:20:29
//

#ifndef FORWARD_DYNAMICS_INTERNAL_TYPES_H
#define FORWARD_DYNAMICS_INTERNAL_TYPES_H

// Include Files
#include "forward_dynamics_types.h"
#include "rtwtypes.h"

// Type Definitions
struct struct_T {
  double Link1[3];
  double Link2[3];
  double Link3[3];
  double Link4[3];
  double Link5[3];
  double EE[3];
};

struct b_struct_T {
  double Link1[60];
  double Link2[60];
  double Link3[60];
  double Link4[60];
  double Link5[60];
  double EE[60];
};

struct c_struct_T {
  double Link1[24];
  double Link2[24];
  double Link3[24];
  double Link4[24];
  double Link5[24];
  double EE[24];
};

struct d_struct_T {
  b_struct_T Jb;
  c_struct_T Ji;
};

struct e_struct_T {
  double Link1[9];
  double Link2[9];
  double Link3[9];
  double Link4[9];
  double Link5[9];
  double EE[9];
};

struct f_struct_T {
  double Link1[16];
  double Link2[16];
  double Link3[16];
  double Link4[16];
  double Link5[16];
  double EE[16];
};

struct g_struct_T {
  double Link1[36];
  double Link2[36];
  double Link3[36];
  double Link4[36];
  double Link5[36];
  double EE[36];
};

struct h_struct_T {
  double g0b[16];
  e_struct_T Rbi;
  struct_T pbi;
  e_struct_T R0i;
  struct_T p0i;
  f_struct_T gbi;
  f_struct_T g0i;
  g_struct_T Adgbi;
  g_struct_T Adg0i;
  g_struct_T Adgbi_inv;
};

#endif
//
// File trailer for forward_dynamics_internal_types.h
//
// [EOF]
//
